
// NLS files structure : 
//
// NLSHEADER + ASCII TO UNICODE MAPPING + UNICODE TO ASCII/UNICODE MAPPING
//


struct NLSHEADER{
	WORD magic_code; // not sure, but it's allways 0xd for real codepage files
	WORD codepage_no;
	WORD mapping_type;	// 1 : ASCII to UNICODE mapping
						// 2 : UNICODE to UNICODE mapping
	WORD dono2;
	WORD dono3;
	WORD dono4;
	WORD dono5;
	WORD dono6;
	WORD dono7;
	WORD dono8;
	WORD dono9;
	WORD dono10;
	WORD dono11;
	WORD ascii2unicode_tbl_size; // in words, not bytes
};