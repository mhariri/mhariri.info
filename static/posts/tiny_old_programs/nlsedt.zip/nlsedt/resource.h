//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by nlsedt.rc
//
#define IDR_MANIFEST                    1
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDC_INFO                        101
#define IDR_MAINFRAME                   128
#define IDR_nlsedtTYPE                  129
#define ID_VIEW_SETFONT                 130
#define IDD_DIALOG1                     131
#define IDD_DIALOG2                     132
#define ID_EDIT_CHANGECODEPAGENO        133
#define ID_VIEW_SHOWNUMBERS             134
#define IDC_EDIT1                       1000
#define IDC_CHECK1                      1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
