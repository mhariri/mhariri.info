// NewValue.cpp : implementation file
//

#include "stdafx.h"
#include "nlsedt.h"
#include "NewValue.h"


// CNewValue dialog

IMPLEMENT_DYNAMIC(CNewValue, CDialog)
CNewValue::CNewValue(CWnd* pParent /*=NULL*/)
	: CDialog(CNewValue::IDD, pParent)
	, m_sNewVal(_T(""))
	, m_bProgressive(TRUE)
	, m_info(_T(""))
{
}

CNewValue::~CNewValue()
{
}

void CNewValue::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_sNewVal);
	DDX_Check(pDX, IDC_CHECK1, m_bProgressive);
	DDX_Text(pDX, IDC_INFO, m_info);
}


BEGIN_MESSAGE_MAP(CNewValue, CDialog)
END_MESSAGE_MAP()


// CNewValue message handlers
