// nlsedt.h : main header file for the nlsedt application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// CnlsedtApp:
// See nlsedt.cpp for the implementation of this class
//

class CnlsedtApp : public CWinApp
{
public:
	CnlsedtApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CnlsedtApp theApp;