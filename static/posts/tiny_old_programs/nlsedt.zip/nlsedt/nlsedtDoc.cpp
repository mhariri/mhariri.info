// nlsedtDoc.cpp : implementation of the CnlsedtDoc class
//

#include "stdafx.h"
#include "nlsedt.h"

#include "nlsedtDoc.h"
#include "nls.h"
#include "CodePageNoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CnlsedtDoc

IMPLEMENT_DYNCREATE(CnlsedtDoc, CDocument)

BEGIN_MESSAGE_MAP(CnlsedtDoc, CDocument)
	ON_COMMAND(ID_EDIT_CHANGECODEPAGENO, OnEditChangecodepageno)
END_MESSAGE_MAP()


// CnlsedtDoc construction/destruction

CnlsedtDoc::CnlsedtDoc()
{
	charmap.SetSize(256);
	for(int i=0; i<charmap.GetCount(); i++)
		charmap[i] = 32;
	codepage_no = 0;
}

CnlsedtDoc::~CnlsedtDoc()
{
}

BOOL CnlsedtDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CnlsedtDoc serialization

void CnlsedtDoc::Serialize(CArchive& ar)
{
	NLSHEADER header;
	if (ar.IsStoring())
	{
		ZeroMemory(&header, sizeof(header));
		header.magic_code = 0xd;
		header.dono2 = header.dono3 = header.dono3 = header.dono4 = header.dono5 = 0x3f;
		header.mapping_type = 1;
		header.ascii2unicode_tbl_size = (WORD)charmap.GetCount();
		if(codepage_no == 0){
			CCodePageNoDlg cod;
			if(cod.DoModal() == IDOK){
				codepage_no = cod.codepage_no;
			}else{
				AfxThrowArchiveException(CArchiveException::generic, L"");
			}
		}
		header.codepage_no = codepage_no;
		ar.Write(&header, sizeof(header));

		// now write ascii to unicode table
		WCHAR *buf = new WCHAR[header.ascii2unicode_tbl_size];
		for(int i=0; i<header.ascii2unicode_tbl_size; i++)
			buf[i] = charmap[i];
		ar.Write(buf, header.ascii2unicode_tbl_size * sizeof(WCHAR));
		delete[] buf;

		// write unicode to ascii table
		char *buf2 = new char[0xffff];
		FillMemory(buf2, 0xffff, '?');
		for(int j=0; j<charmap.GetCount(); j++)
			buf2[charmap[j]] = j;
		ar.Write(buf2, 0xffff);
		delete[] buf2;



	}
	else
	{
		ar.Read(&header, sizeof(header));

		// check magic number
		if(header.magic_code != 0xd) {
			AfxMessageBox(L"Not a compatible codepage file, magic numebr should be 0xd.");
			AfxThrowArchiveException(CArchiveException::generic, L"");
		}

		// check mapping type to be ascii to unicode
		if(header.mapping_type != 1) {
			AfxMessageBox(L"Not a compatible codepage file, it's not ascii to unicode, maybe unicode to unicode format.");
			AfxThrowArchiveException(CArchiveException::generic, L"");
		}

		WCHAR *buf = new WCHAR[header.ascii2unicode_tbl_size];
		ar.Read(buf, header.ascii2unicode_tbl_size * sizeof(WCHAR));
		charmap.RemoveAll();
		charmap.SetSize(header.ascii2unicode_tbl_size);
		for(int i=0; i<header.ascii2unicode_tbl_size; i++)
			charmap[i] = buf[i];
		delete[] buf;

		codepage_no = header.codepage_no;

	}
}


// CnlsedtDoc diagnostics

#ifdef _DEBUG
void CnlsedtDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CnlsedtDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CnlsedtDoc commands

void CnlsedtDoc::OnEditChangecodepageno()
{
		CCodePageNoDlg cod;
		cod.codepage_no = codepage_no;
		if(cod.DoModal() == IDOK){
			codepage_no = cod.codepage_no;
		}
}
