// nlsedtDoc.h : interface of the CnlsedtDoc class
//


#pragma once

class CnlsedtDoc : public CDocument
{
protected: // create from serialization only
	CnlsedtDoc();
	DECLARE_DYNCREATE(CnlsedtDoc)

// Attributes
public:
	CArray<WCHAR> charmap;
	WORD codepage_no;

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CnlsedtDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEditChangecodepageno();
};


