// CodePageNoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "nlsedt.h"
#include "CodePageNoDlg.h"


// CCodePageNoDlg dialog

IMPLEMENT_DYNAMIC(CCodePageNoDlg, CDialog)
CCodePageNoDlg::CCodePageNoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCodePageNoDlg::IDD, pParent)
	, codepage_no(0)
{
}

CCodePageNoDlg::~CCodePageNoDlg()
{
}

void CCodePageNoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, codepage_no);
}


BEGIN_MESSAGE_MAP(CCodePageNoDlg, CDialog)
END_MESSAGE_MAP()


// CCodePageNoDlg message handlers
