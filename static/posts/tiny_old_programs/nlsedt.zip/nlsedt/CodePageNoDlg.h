#pragma once


// CCodePageNoDlg dialog

class CCodePageNoDlg : public CDialog
{
	DECLARE_DYNAMIC(CCodePageNoDlg)

public:
	CCodePageNoDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCodePageNoDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	UINT codepage_no;
};
