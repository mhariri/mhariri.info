// nlsedtView.cpp : implementation of the CnlsedtView class
//

#include "stdafx.h"
#include "nlsedt.h"

#include "nlsedtDoc.h"
#include "nlsedtView.h"
#include "NewValue.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CnlsedtView

IMPLEMENT_DYNCREATE(CnlsedtView, CScrollView)

BEGIN_MESSAGE_MAP(CnlsedtView, CScrollView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_COMMAND(ID_VIEW_SETFONT, OnSetFont)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_VIEW_SHOWNUMBERS, OnViewShownumbers)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWNUMBERS, OnUpdateViewShownumbers)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
END_MESSAGE_MAP()

// CnlsedtView construction/destruction

CnlsedtView::CnlsedtView()
{
	font_size = 100;
	font_face = _T ("Arial");
	m_bShowNums = 1;
	m_aSelection.SetSize(0);
}

CnlsedtView::~CnlsedtView()
{
}

BOOL CnlsedtView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

// CnlsedtView drawing

COLORREF ALL_COLORS[] =  {RGB(0, 255, 255),RGB (100, 200, 200)} ;
COLORREF SEL_COLORS[] = {RGB(255, 0, 0),RGB (155, 55, 55)} ;
#define HEIGHT	25
#define WIDTH	35
#define COLS	16
void CnlsedtView::OnDraw(CDC* pDC)
{
	CnlsedtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    CFont font;
    font.CreatePointFont (font_size, font_face);

    pDC->SelectObject (&font);
    pDC->SetBkMode (TRANSPARENT);

	pDC->SetTextColor(RGB(0,0,0));


	for(int i=0; i<pDoc->charmap.GetCount(); i++){
		CBrush brush(ALL_COLORS[i%(sizeof(ALL_COLORS)/sizeof(COLORREF))]);
		for(int j=0; j<m_aSelection.GetCount(); j++)
			if(m_aSelection[j] == i){
				brush.DeleteObject();
				brush.CreateSolidBrush(SEL_COLORS[i%(sizeof(SEL_COLORS)/sizeof(COLORREF))]);
			}


		CRect rect = GetBoxRect(i);
		pDC->FillRect(rect, &brush);
		CString s;
		s.AppendChar(pDoc->charmap[i]);
		pDC->DrawText(s, rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	}

	if(m_bShowNums){
		CFont font2;
		font2.CreatePointFont ((int)(font_size/1.7), font_face);

		pDC->SelectObject (&font2);
		for(int i=0; i<pDoc->charmap.GetCount(); i++){
			CString s;
			s.Format(L"%d", i);
			pDC->DrawText(s, GetBoxRect(i), DT_SINGLELINE | DT_LEFT | DT_TOP);
		}
	}
}


// CnlsedtView printing

BOOL CnlsedtView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CnlsedtView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CnlsedtView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CnlsedtView diagnostics

#ifdef _DEBUG
void CnlsedtView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CnlsedtView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CnlsedtDoc* CnlsedtView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CnlsedtDoc)));
	return (CnlsedtDoc*)m_pDocument;
}
#endif //_DEBUG


// CnlsedtView message handlers

void CnlsedtView::OnSetFont()
{
	CHARFORMAT ch;
	ch.cbSize = sizeof(ch);
	ZeroMemory(&ch, sizeof(ch));
	wcscpy(ch.szFaceName, font_face);
	ch.cbSize = font_size;
	ch.dwMask = CFM_FACE | CFM_SIZE;
	CFontDialog cf(ch);
	if(cf.DoModal() == IDOK){
		font_face = cf.GetFaceName();
		font_size = cf.GetSize();
		Invalidate();
	}

}
void CnlsedtView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	CnlsedtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	point.Offset(GetScrollPosition());
	for(int i=0; i<pDoc->charmap.GetCount(); i++){
		if(GetBoxRect(i).PtInRect(point)){
			BOOL show_next = 1;
			while(show_next){
				CNewValue n;
				n.m_sNewVal.AppendChar(pDoc->charmap[i]);
				n.m_info.Format(L"Char. Code : %d(0x%x)\nOld value : %d(0x%x) -> ",
									i, i, pDoc->charmap[i], pDoc->charmap[i]);
				n.m_info.AppendChar(pDoc->charmap[i]);
				if(n.DoModal() == IDOK){
					if(pDoc->charmap[i] != n.m_sNewVal.GetAt(0))
						pDoc->SetModifiedFlag();
					pDoc->charmap[i] = n.m_sNewVal.GetAt(0);
					Invalidate();
					show_next = n.m_bProgressive;
				}else
					show_next = 0;
				i++;
			}
			return;
		}
	}
	
}

void CnlsedtView::OnMouseMove(UINT nFlags, CPoint point)
{
	CnlsedtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	point.Offset(GetScrollPosition());
	for(int i=0; i<pDoc->charmap.GetCount(); i++){
		if(GetBoxRect(i).PtInRect(point)){
			CString s;
			s.Format(L"Char: %d(0x%x), Value: %d(0x%x)", i, i,
							pDoc->charmap[i],pDoc->charmap[i]);
			GetParentFrame()->SetMessageText(s);
			return;
		}
	}
	GetParentFrame()->SetMessageText(L"");
	
}

void CnlsedtView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CnlsedtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(!(nFlags & MK_CONTROL) && !m_aSelection.IsEmpty()){
		m_aSelection.RemoveAll();
		Invalidate();
	}


	point.Offset(GetScrollPosition());
	for(int i=0; i<pDoc->charmap.GetCount(); i++){
		if(GetBoxRect(i).PtInRect(point)){
			m_aSelection.Add(i);
			Invalidate();
			return;
		}
	}
}

void CnlsedtView::OnInitialUpdate(){ // called first time after construct
	CScrollView::OnInitialUpdate();

	UpdateScrollSize();
}

void CnlsedtView::UpdateScrollSize(void)
{
	SetScrollSizes (MM_TEXT, CSize (COLS * WIDTH, (int)GetDocument()->charmap.GetCount() / COLS * HEIGHT),
		CSize (1, 1), CSize(WIDTH, HEIGHT));
	ScrollToPosition (CPoint (0, 0));
}

void CnlsedtView::OnViewShownumbers()
{
	m_bShowNums = !m_bShowNums;
	Invalidate();
}

void CnlsedtView::OnUpdateViewShownumbers(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_bShowNums);
}

CRect CnlsedtView::GetBoxRect(int i)
{
	int row = i / COLS;
	int col = i % COLS;
	return CRect(col * WIDTH + 1,row * HEIGHT + 1, col * WIDTH + WIDTH - 2, row * HEIGHT + HEIGHT - 2);
}
void CnlsedtView::OnUpdateEditPaste(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!m_aSelection.IsEmpty() && ::IsClipboardFormatAvailable(CF_UNICODETEXT));
}

void CnlsedtView::OnUpdateEditCopy(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!m_aSelection.IsEmpty());
}

void CnlsedtView::OnEditCopy()
{
	CnlsedtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CString s;
	for(int i=0; i<m_aSelection.GetCount(); i++)
		s.AppendChar(pDoc->charmap[m_aSelection[i]]);

	if (::OpenClipboard (m_hWnd)) {
		::EmptyClipboard ();

		HANDLE hData = ::GlobalAlloc (GMEM_MOVEABLE, s.GetLength() * sizeof(WCHAR) + 2);
		WCHAR * pData = (WCHAR *) ::GlobalLock (hData);
		wcscpy (pData, s);
		::GlobalUnlock (hData);

		::SetClipboardData (CF_UNICODETEXT, hData);
		::CloseClipboard ();
	}
}

void CnlsedtView::OnEditPaste()
{
	CnlsedtDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	WCHAR szText[1024];
	if (::OpenClipboard (m_hWnd)) {
		HANDLE hData = ::GetClipboardData (CF_UNICODETEXT);
		if (hData != NULL) {
			WCHAR * pData = (WCHAR *) ::GlobalLock (hData);
			if (::wcslen (pData) < sizeof(szText)/sizeof(WCHAR))
				::wcscpy (szText, pData);
			::GlobalUnlock (hData);
		}
		::CloseClipboard ();
	}
	for(int i=0; i< min((int)m_aSelection.GetCount(), (int)wcslen(szText)); i++)
		pDoc->charmap[m_aSelection[i]] = szText[i];

	Invalidate();


}
