// nlsedtView.h : interface of the CnlsedtView class
//


#pragma once


class CnlsedtView : public CScrollView
{
protected: // create from serialization only
	CnlsedtView();
	DECLARE_DYNCREATE(CnlsedtView)

// Attributes
public:
	CnlsedtDoc* GetDocument() const;

// Operations
public:

private:
	CString font_face;
	int font_size;
	BOOL m_bShowNums;
	CArray<int> m_aSelection;

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual void OnMouseMove(UINT nFlags, CPoint point);
	virtual void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnInitialUpdate(); // called first time after construct
	CRect GetBoxRect(int i);


// Implementation
public:
	virtual ~CnlsedtView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSetFont();
	void UpdateScrollSize(void);
	afx_msg void OnViewShownumbers();
	afx_msg void OnUpdateViewShownumbers(CCmdUI *pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditPaste(CCmdUI *pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI *pCmdUI);
	afx_msg void OnEditPaste();
};

#ifndef _DEBUG  // debug version in nlsedtView.cpp
inline CnlsedtDoc* CnlsedtView::GetDocument() const
   { return reinterpret_cast<CnlsedtDoc*>(m_pDocument); }
#endif

