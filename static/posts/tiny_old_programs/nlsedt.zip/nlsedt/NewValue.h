#pragma once


// CNewValue dialog

class CNewValue : public CDialog
{
	DECLARE_DYNAMIC(CNewValue)

public:
	CNewValue(CWnd* pParent = NULL);   // standard constructor
	virtual ~CNewValue();

// Dialog Data
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_sNewVal;
	BOOL m_bProgressive;
	CString m_info;
};
