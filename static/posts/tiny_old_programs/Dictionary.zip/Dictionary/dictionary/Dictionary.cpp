#include "stdafx.h"
#include "resource.h"

#define total_words 52319L

char *wordlistfile="words",
	  *defdatafile="dicp.dat",
	  *definfo="dicp.ind",
	  *fontsfile="fonts";

char *defname="defwindow";

char *abouttext="English to Persian Dictionary\n\n"
					 "Programmed by Mohsen Hariri\n"
					 "                         Feb,2000";


int dicsize_x=640,
	 dicsize_y=300;

int userchange=TRUE;        //to check if the user has changed the word

char *wordslist,*defdata;
long count=0;
int words_per_page=12;
int lastsel=0;
char fonts[4096];
WNDCLASS defClass;
HWND hWnd_parent,hWnd_word,hWnd_wordslist,
	  hWnd_def,hWnd_scrollbar,hWnd_about,hWnd_per2eng;

RECT rc={0,0,405, 160};




LRESULT CALLBACK dictasks(HWND,UINT,WPARAM,LPARAM);
void FindDef(long);
void SetWords(long);


int PASCAL WinMain(HINSTANCE hInst,HINSTANCE,LPSTR,int cmdshow) 
{
			HANDLE file;
			DWORD filesize,readcount;
			int result;
			 MSG msg;




		  defClass.style          = 0;
		  defClass.lpfnWndProc    = dictasks;
		  defClass.cbClsExtra     = 0;
		  defClass.cbWndExtra     = 0;
		  defClass.hInstance      = hInst;
		  defClass.hIcon          = LoadIcon(hInst,(LPCSTR)IDI_ICON1);
		  defClass.hCursor        = LoadCursor(NULL, IDC_ARROW);
		  defClass.hbrBackground  = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
		  defClass.lpszMenuName   = NULL;
		  defClass.lpszClassName  = defname;


		  if(!RegisterClass(&defClass))MessageBox(NULL,"Error registering!","",MB_OK);





													  //Read words list file
						  file=CreateFile(wordlistfile,GENERIC_READ,0,NULL,OPEN_EXISTING,
						  FILE_ATTRIBUTE_NORMAL,NULL);
						  if(file==INVALID_HANDLE_VALUE)
						  MessageBox(NULL,"words data file not fount!","Error",MB_OK);
						  filesize=GetFileSize(file,NULL);
						  wordslist=(char *)GlobalAlloc(GMEM_FIXED,filesize);
						  result=ReadFile(file,wordslist,filesize,&readcount,NULL);
						 if(!result)MessageBox(NULL,"Error while reading words file!","Error",MB_OK);
					  CloseHandle(file);


													  //Read fonts file
						  file=CreateFile(fontsfile,GENERIC_READ,0,NULL,OPEN_EXISTING,
						  FILE_ATTRIBUTE_NORMAL,NULL);
						  if(file==INVALID_HANDLE_VALUE)
						  MessageBox(NULL,"fonts file not fount!","Error",MB_OK);
						  result=ReadFile(file,fonts,4096,&readcount,NULL);
						 if(!result)MessageBox(NULL,"Error while reading fonts file!","Error",MB_OK);
					  CloseHandle(file);












hWnd_parent=CreateWindow(defname,"DICTIONARY",
							  WS_SYSMENU|WS_DLGFRAME|0x4L|WS_GROUP
							  ,0,50,dicsize_x,dicsize_y,NULL,NULL,hInst,NULL);
SelectObject(GetDC(hWnd_parent),GetStockObject(BLACK_BRUSH));


CreateWindow("STATIC"," Enter the word:",
						  SS_SIMPLE|WS_CHILD|WS_VISIBLE, 10,15,
						  100, 15, hWnd_parent, NULL, hInst, NULL);

hWnd_word=CreateWindow("EDIT",NULL,
						  ES_AUTOHSCROLL|WS_CHILD|WS_VISIBLE|ES_NOHIDESEL|WS_BORDER, 10,30,
						  200, 20, hWnd_parent, NULL, hInst, NULL);

hWnd_wordslist=CreateWindow("LISTBOX","words list",
						  ES_AUTOHSCROLL|WS_BORDER|WS_CHILD|WS_VISIBLE|LBS_NOTIFY, 10,60,
						  200, 200, hWnd_parent, NULL, hInst, NULL);

hWnd_scrollbar=CreateWindow("SCROLLBAR","scroll bar",
						  SBS_VERT|WS_CHILD|WS_VISIBLE, 211,59,
						  14, 193, hWnd_parent, NULL, hInst, NULL);

SetScrollRange(hWnd_scrollbar,SB_CTL,0,total_words-words_per_page,TRUE);


hWnd_def = CreateWindow(defname,"DEFINITION WINDOW",
						  WS_BORDER|WS_CHILD|WS_VISIBLE, 227,60,
						  405, 160, hWnd_parent, NULL, hInst, NULL);

hWnd_about=CreateWindow("BUTTON","?",
						  WS_CHILD|WS_VISIBLE,610 ,10,
						  15, 15, hWnd_parent, NULL, hInst, NULL);
hWnd_per2eng=CreateWindow("BUTTON","Persian to English",
						  WS_CHILD|WS_VISIBLE,400 ,10,
						  180, 25, hWnd_parent, NULL, hInst, NULL);


UpdateWindow(hWnd_parent);
ShowWindow(hWnd_parent,cmdshow);




SetWords(0);
FindDef(0);
SendMessage(hWnd_wordslist,LB_SETCURSEL,0,0);
SetFocus(hWnd_word);
SetWindowText(hWnd_word,wordslist);
SendMessage(hWnd_word,EM_SETSEL,0,-1);






while(GetMessage(&msg,NULL,0,0))
	  {TranslateMessage(&msg);
	  DispatchMessage(&msg);
	  }

			GlobalFree((HGLOBAL)wordslist);

return(msg.wParam);
}


LRESULT CALLBACK dictasks(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
switch(msg)
 {
 case WM_CTLCOLORSTATIC:
		SetBkMode((HDC)wParam,TRANSPARENT);
		break;

 case WM_VSCROLL:
		 switch(int(LOWORD(wParam)))
		 {
			case SB_LINEUP:
				  if(count)count--;
				  break;

			case SB_LINEDOWN:
				  if(total_words-words_per_page>count)count++;
				  break;

			case SB_PAGEDOWN:
				  count+=words_per_page;
				  if(total_words-words_per_page<count)
					 count=total_words-words_per_page;
				  break;

			case SB_PAGEUP:
				  count-=words_per_page;
				  if(count<0)count=0;
				  break;

			case SB_THUMBPOSITION:
			case SB_THUMBTRACK:
				  count=(int) HIWORD(wParam);
				  break;

		 }
		  SetScrollPos(hWnd_scrollbar,SB_CTL,count,TRUE);
		 SetWords(count);
		 if(lastsel-count<=words_per_page)
		 SendMessage(hWnd_wordslist,LB_SETCURSEL,lastsel-count,0);
		 SetFocus(hWnd_word);
		 break;

 case WM_COMMAND:
  if((HIWORD(wParam)==LBN_SELCHANGE)&&((HWND) lParam==hWnd_wordslist))
		{
		int sel;

		sel=SendMessage(hWnd_wordslist,LB_GETCURSEL,0,0);
		FindDef(count+sel);
		userchange=FALSE;
		SetWindowText(hWnd_word,wordslist+((count+sel)*33));
		userchange=TRUE;
		SetFocus(hWnd_word);
		SendMessage(hWnd_word,EM_SETSEL,0,-1);
		}

  if(HWND(lParam)==hWnd_about)
	  {MessageBox(hWnd_parent,abouttext,"About...",MB_ICONINFORMATION|MB_OK);
		SetFocus(hWnd_word);
	  }

  if(HWND(lParam)==hWnd_per2eng)
	  {
	  WinExec("per2eng dic.exe",SW_SHOWNORMAL);
	  SendMessage(hWnd,WM_CLOSE,0,0);
	  }
  


  if((HIWORD(wParam)==EN_CHANGE)&&((HWND) lParam==hWnd_word)&&userchange)
		{
		int down,up,i,cmp;
		char word[50];
		down=total_words-1;
		up=-1;

		GetWindowText(hWnd_word,word,50);

		do{
		i=(down-up)/2+up;
		cmp=lstrcmpi(wordslist+i*33L,word);

		if(cmp<0)up=i;
		else
		{
		if(cmp>0)down=i;
		else {up=i;down=i;} //they are equal!!
		}
		}while(down-up>1);
		SetWords(down);
		FindDef(down);
		SendMessage(hWnd_wordslist,LB_SETCURSEL,0,0);
		count=down;
		SetScrollPos(hWnd_scrollbar,SB_CTL,count,TRUE);

		}

		break;

 case WM_PAINT:
		long ret_val;
		ret_val=DefWindowProc(hWnd,msg,wParam,lParam);
		FindDef(lastsel);
		return(ret_val);


 case WM_CLOSE:
		if(hWnd==hWnd_parent)PostQuitMessage(0);
		break;

 case WM_QUIT:
		PostQuitMessage(0);
		break;

 case WM_SETFOCUS:
		SetFocus(hWnd_word);



 default: return(DefWindowProc(hWnd,msg,wParam,lParam));
 }
return(0);
}


void FindDef(long wordcount)
{
UINT x1,x2;
HANDLE file;
DWORD readcount;
int result,i,j,z,k;
char definition_string[100];


file=CreateFile(definfo,GENERIC_READ,0,NULL,OPEN_EXISTING,
					FILE_ATTRIBUTE_NORMAL,NULL);
if(file==INVALID_HANDLE_VALUE)MessageBox(hWnd_parent,"def info file not fount!","Error",MB_OK);
SetFilePointer(file,wordcount*2,NULL,FILE_BEGIN	);
x1=0;
x2=0;
ReadFile(file,&x1,2,&readcount,NULL);
ReadFile(file,&x2,2,&readcount,NULL);

CloseHandle(file);

										  //Read definitions file
file=CreateFile(defdatafile,GENERIC_READ,0,NULL,OPEN_EXISTING,
					FILE_ATTRIBUTE_NORMAL,NULL);
if(file==INVALID_HANDLE_VALUE)MessageBox(hWnd_parent,"definitions data file not fount!","Error",MB_OK);
	 SetFilePointer(file,x1*51+1,NULL,FILE_BEGIN	);


HDC def;
def=GetDC(hWnd_def);

FillRect(def,&rc,(HBRUSH)GetStockObject(LTGRAY_BRUSH));
if(x2<=x1)x2=x1+1;
					 for(i=0;i<(x2-x1);i++)  //this will write persian definition
					 {
					 result=ReadFile(file,definition_string,51,&readcount,NULL);
					 if(!result)MessageBox(hWnd_parent,"Error while reading definitions file!","Error",MB_OK);
					 for(z=0;z<50;z++)
					 for(k=0;k<16;k++)
					 for(j=0;j<8;j++)
					 if(*(fonts+(unsigned char)definition_string[z]*16+k)&(1<<j))
						 SetPixel(def,z*8+j,k+i*16,0);
					 }
					  CloseHandle(file);


ReleaseDC(hWnd_def,def);

lastsel=wordcount;
}



void SetWords(long where)
{
 int i;
 char *first_word;

 SendMessage(hWnd_wordslist,LB_RESETCONTENT,0,0);
 first_word=wordslist+33L*where;

  for(i=0;i<words_per_page;i++)
	  SendMessage(hWnd_wordslist,LB_ADDSTRING,0,(LPARAM) (LPCTSTR) (first_word+33*i));

}





