#include "stdafx.h"


//procedures and functions
LONG PASCAL far DecodeMessage(HWND,UINT,WPARAM,LPARAM);
void Mixup();
void InitPuzzle();
void ExtractAllIcons();
void SetMem();
void UnsetMem();
void DoPaint();
void NewGame(int,int);
void UncheckAllBut(int);
void UncheckAllBut2(int);
BOOL far pascal About(HWND,UINT,WPARAM,LPARAM);
BOOL far pascal Custom(HWND,UINT,WPARAM,LPARAM);
BOOL far pascal CustomFlashTime(HWND,UINT,WPARAM,LPARAM);
void CALLBACK timertasks(HWND,UINT,UINT,DWORD);
void CALLBACK Hidepic(HWND,UINT,UINT,DWORD);
DWORD PlayMidiFile(HWND,LPSTR);
void StopMusic();
void ShowMCIError(DWORD);
void ReadSetupFile(HMENU *);
void WriteSetupFile();
void UNINSTALLWinMem();
int random(int);


//constants
#define lngth 32
#define wdth  32
#define ID_TIM1 1
#define ID_TIM2 2
#define MIXING_REPEAT 10
#define HARDFLASH 200
#define MEDFLASH 500
#define EASYFLASH 900
#define BACKCOLOR RGB(150,150,150)
#define TOP_HEIGHT 32
#define HEIGHTMAX 128
#define LENGTHMAX 128
#define total_menue_items 15

//variables
int xmax=7,
	 ymax=6,
	 FlashTime=MEDFLASH, //time in miliseconds
	 *basepuzzle,*showpuzzle,   //puzzle pictures
	 secondselection=FALSE,
	 selected2,selected1,
	 showremained=FALSE,
	 TimerOn=FALSE,
	 soundon=TRUE,
	 musicon=FALSE,
	 mousekeydown=FALSE,
	 found=0,
	 remained=xmax*ymax,
	 cheat=0,
	 MENU_HEIGHT,
	 lastpressedbox,
	 midicount=0;


HICON icon1,icon2,icon3,icon4,icon5;
DWORD musicdevice,
		EllapsedTime;
long cheatword[16]={3276801L,1572865L,2293761L,       //cheat code  ???master :)
						  2031617L,1179649L,3211265L,
						  1507329L,2031617L,3276801L,
						  1376257L,3276801L,1966081L,
						  2031617L,1310721L,1179649L,1245185L};
char *name="memClass",
	  *ICON_FILE="boyzone.icl",
	  

	 /* midifiles[]="E:\\boyzone lyrics\\midies\\adb.mid\0"
					  "E:\\boyzone lyrics\\midies\\allthat.mid\0"
					  "E:\\boyzone lyrics\\midies\\andi.mid\0"
					  "E:\\boyzone lyrics\\midies\\babycan.mid\0"
					  "E:\\boyzone lyrics\\midies\\lovemefo.mid\0"
					  "E:\\boyzone lyrics\\midies\\nomatter.mid\0"
					  "E:\\boyzone lyrics\\midies\\whenthe.mid\0"
					  "E:\\boyzone lyrics\\midies\\whenyou.mid\0"
					  "E:\\boyzone lyrics\\midies\\working.mid\0"
					  "E:\\boyzone lyrics\\midies\\youneede.mid\0"
					"\0",*/
#ifdef _DEBUG 
	  midifiles[]=    //"adb.mid\0"
					  //"allthat.mid\0"
					  //"andi.mid\0"
					  "..\\babycan.mid\0"
					  //"lovemefo.mid\0"
					  "..\\nomatter.mid\0"
					  //"whenthe.mid\0"
					  //"whenyou.mid\0"
					  //"working.mid\0"
					  "..\\youneede.mid\0"
					  "..\\words.mid\0"
					  "\0",
#else

	  midifiles[]=    //"adb.mid\0"
					  //"allthat.mid\0"
					  //"andi.mid\0"
					  "babycan.mid\0"
					  //"lovemefo.mid\0"
					  "nomatter.mid\0"
					  //"whenthe.mid\0"
					  //"whenyou.mid\0"
					  //"working.mid\0"
					  "youneede.mid\0"
					  "words.mid\0"
					  "\0",
#endif


	  tempmidi[100];



HINSTANCE hInst;
HWND hnd;
HICON *icons;
HBRUSH BackGround;
RECT rc;







//main procedure
int PASCAL WinMain(HINSTANCE hInstance,HINSTANCE,
						 LPSTR cmdLine,int nCmdShow)


{      WNDCLASS wndClass;
		 MSG      msg;
		 HWND     hWnd;
		 HMENU    menu;

/*if(lstrcmpi(cmdLine,"/UNINSTALL"))
{UNINSTALLWinMem();
 return(0);
}*/
BackGround=CreateSolidBrush(BACKCOLOR);

ReadSetupFile(&menu);


if(FindWindow(name,"mem")!=NULL)
{
SetForegroundWindow(FindWindow(name,"mem"));
return(0);
}
	 hInst=hInstance;

		  wndClass.style          = 0;
		  wndClass.lpfnWndProc    = DecodeMessage;
		  wndClass.cbClsExtra     = 0;
		  wndClass.cbWndExtra     = 0;
		  wndClass.hInstance      = hInstance;
		  wndClass.hIcon          = LoadIcon(hInstance,MAKEINTRESOURCE(ICON_1));
		  wndClass.hCursor        = LoadCursor(NULL, IDC_ARROW);
		  wndClass.hbrBackground  = NULL;
		  wndClass.lpszMenuName   = NULL;
		  wndClass.lpszClassName  = name;

		  if (!RegisterClass(&wndClass))
				return FALSE;

hWnd = CreateWindow(name, "Mem",
						  WS_MINIMIZEBOX|WS_SYSMENU|WS_OVERLAPPED, CW_USEDEFAULT,
						  CW_USEDEFAULT,
						  wdth*xmax, ymax*lngth, NULL, NULL, hInstance, NULL);

SetMenu(hWnd,menu);
GetClientRect(hWnd,&rc);
MENU_HEIGHT=ymax*lngth-(rc.bottom-rc.top);
SetWindowPos(hnd,HWND_TOP,0,0,xmax*wdth+6,ymax*lngth+MENU_HEIGHT+TOP_HEIGHT,SWP_NOMOVE);
GetClientRect(hWnd,&rc);


	if (!hWnd) return(FALSE);



	ShowWindow(hWnd,nCmdShow);


	while(GetMessage(&msg,NULL,0,0))
			{
			 TranslateMessage(&msg);
			 DispatchMessage(&msg);
			}


return(0);
}


LONG PASCAL far DecodeMessage(HWND hWnd,UINT Message,
										WPARAM wParam,LPARAM lParam)

	  {

int x,y,j,z;


				 switch(Message)
			{

		  case WM_CREATE:
				 hnd=hWnd;
				 SetMem();
				 InitPuzzle();
				 ExtractAllIcons();
				 Mixup();
				 if(musicon)
					 PostMessage(hWnd,MM_MCINOTIFY,0,0);
				 DragAcceptFiles(hWnd,TRUE);
				 remained=xmax*ymax;
				 break;


		  case WM_LBUTTONDOWN:            	  //invoked when a button is pressed
				 if(showremained) Hidepic(hWnd,0,0,0);

			  SetCapture(hWnd);
				 mousekeydown=TRUE;
				 y=HIWORD(lParam)-TOP_HEIGHT;
					 if(y>=0)
				 {
				 x=LOWORD(lParam)/wdth;
				 y/=lngth;
				 j=x+y*xmax;
				 if(showpuzzle[j]<0)
				 {showpuzzle[j]=-1;
				 DoPaint();
				 lastpressedbox=j;
				 }}
				 break;

		  case WM_KEYDOWN:

				 if(cheatword[cheat]==lParam)cheat++;else cheat=0;
				 if(cheat==16)
				 {for(x=0;x<xmax*ymax;x++)
				 showpuzzle[x]=basepuzzle[x];
				 remained=0;found=xmax*ymax;
				 KillTimer(hWnd,ID_TIM1);
				 DoPaint();
				 if(soundon)sndPlaySound("mem4",SND_ASYNC);
				 if(MessageBox(hnd,"LEVEL COMPLETED!\nPlay again? ","FINISHED",MB_YESNO)==IDNO)
				 PostQuitMessage(0);
				 NewGame(xmax,ymax);

				 }
				 break;


		  case WM_MOUSEMOVE:
				 if(mousekeydown)
				 {
				 if(lastpressedbox>=0){showpuzzle[lastpressedbox]=-2;lastpressedbox=-1;}
				 x=LOWORD(lParam);
				 y=(HIWORD(lParam)-TOP_HEIGHT);
				 if((y>=0)&&(x>=0))
				 {x/=wdth;
				 y/=lngth;
				 if((x<xmax)&&(y<ymax))
				 {j=x+y*xmax;
				 if(showpuzzle[j]==-2)
				 {showpuzzle[j]=-1;
				 lastpressedbox=j;
				 }}}
				 DoPaint();
				 }
				 break;

		  case WM_LBUTTONUP:
				 if(mousekeydown)
				 {
				 ReleaseCapture();
				 mousekeydown=FALSE;
				 if(lastpressedbox>=0)
				 {showpuzzle[lastpressedbox]=-2;
				 if (!TimerOn)
				 {SetTimer(hWnd,ID_TIM1,1000,(TIMERPROC)timertasks);
				 TimerOn=TRUE;
				 }
				 if(showpuzzle[lastpressedbox]<0) //if it is not solved before
				 if(secondselection==FALSE)      // and it is the first selection then...
				 {
				 if(soundon)sndPlaySound("mem1",SND_ASYNC);
				 selected1=lastpressedbox;
				 showpuzzle[selected1]=-1;
				 secondselection=TRUE;
				 }else          //else if it is the second selection...
				 {secondselection=FALSE;
				 selected2=lastpressedbox;
				 if((selected2==selected1))  //if two selections are the same
				 showpuzzle[selected1]=-2;
				 else
				 {
				 showpuzzle[selected1]=basepuzzle[selected1];
				 showpuzzle[selected2]=basepuzzle[selected2];
				 if(!(basepuzzle[selected1]==basepuzzle[selected2]))
				 {if(soundon)sndPlaySound("mem2",SND_ASYNC);
				 SetTimer(hWnd,ID_TIM2,FlashTime,(TIMERPROC)Hidepic);
				 showremained=TRUE;}
				 else
				 {if(soundon)sndPlaySound("mem3",SND_ASYNC);
				 found+=2;remained-=2;
				 if (!remained)
				 {KillTimer(hWnd,ID_TIM1);
				 DoPaint();
				 if(soundon)sndPlaySound("mem4",SND_ASYNC);
				 if(MessageBox(hnd,"PUZZLE COMPLETED!\nPlay again? ","",MB_YESNO)==IDNO)
				 PostQuitMessage(0);
				 NewGame(xmax,ymax);
				 }}}}}
				  DoPaint();
				  }
				  lastpressedbox=-1;
				  break;

		  case WM_PAINT:
				 DoPaint();
				 break;

		  case WM_COMMAND:
		  {
			 switch( GET_WM_COMMAND_ID(wParam,lParam) )

				{
				  case CM_ITEM1:
					 NewGame(xmax,ymax);
					 break;

				  case CM_ITEM2:
					 PostQuitMessage(0);
					 break;


				  case CM_ITEM3:
					 UncheckAllBut(CM_ITEM3);
					 NewGame(7,4);
					 break;


				  case CM_ITEM4:
					 UncheckAllBut(CM_ITEM4);
					 NewGame(7,6);
					 break;


				  case CM_ITEM5:
					 UncheckAllBut(CM_ITEM5);
					 NewGame(8,8);
					 break;


				  case CM_ITEM6:
					 UncheckAllBut(CM_ITEM6);
					 DialogBox(hInst,
								MAKEINTRESOURCE(CustomSize),
								hWnd,
								(DLGPROC)Custom);
					 NewGame(xmax,ymax);
					 break;


				  case CM_ITEM7:
					 DialogBox(hInst,
								MAKEINTRESOURCE(HelpBox),
								hWnd,
								(DLGPROC)About);
					 break;


				  case CM_ITEM8:
					 DialogBox(hInst,
								MAKEINTRESOURCE(AboutBox),
								hWnd,
								(DLGPROC)About);
					 break;


				  case CM_ITEM9:
					 UncheckAllBut2(CM_ITEM9);
					 FlashTime=EASYFLASH;
					 break;


				  case CM_ITEM10:
					 UncheckAllBut2(CM_ITEM10);
					 FlashTime=MEDFLASH;
					 break;


				  case CM_ITEM11:
					 UncheckAllBut2(CM_ITEM11);
					 FlashTime=HARDFLASH;
					 break;


				  case CM_ITEM12:
					 UncheckAllBut2(CM_ITEM12);
					 DialogBox(hInst,
								MAKEINTRESOURCE(CustomFlash),
								hWnd,
								(DLGPROC)CustomFlashTime);
					 break;

				  case CM_ITEM13:
					 soundon=!soundon;
					 if(soundon)CheckMenuItem(GetMenu(hWnd),CM_ITEM13,MF_CHECKED);
					 else CheckMenuItem(GetMenu(hWnd),CM_ITEM13,MF_UNCHECKED);

					 break;


				 case CM_ITEM14:
				 if(musicon)
				 {
				 musicon=FALSE;
				 StopMusic();
				 CheckMenuItem(GetMenu(hWnd),CM_ITEM14,MF_UNCHECKED);
				 }
				 else
				 {
				 musicon=TRUE;
				 CheckMenuItem(GetMenu(hWnd),CM_ITEM14,MF_CHECKED);
				 PostMessage(hWnd,MM_MCINOTIFY,0,0);
				 }
				  break;

				 case CM_ITEM15:
				  if(musicon)
					SendMessage(hWnd,WM_COMMAND,MM_MCINOTIFY,0);
					break;
				}
				 break;
			  }


		  case MM_MCINOTIFY:
			  LPSTR mn;
			 if(musicon)
			 {StopMusic();
			 char *midifilename;
			 if(midicount!=-1)
			 {
			 midifilename=midifiles;
			 midicount++;
			 for(z=0;z<midicount;z++)midifilename+=lstrlen(midifilename)+1;
			 if(*midifilename=='\0')
			 {midifilename=midifiles;
			 midicount=0;
			 }
			 if(!CreateFile(midifilename,0, 0, NULL, OPEN_EXISTING, 0, NULL))
			 {
				 midicount++;
			     PostMessage(hWnd,MM_MCINOTIFY,0,0);
				 break;
			 }			 
				 GetModuleFileName(NULL,tempmidi+50,sizeof(tempmidi)-50);
				 GetFullPathName(tempmidi+50,sizeof(tempmidi),tempmidi,&mn);
				 *mn=0;
				 strcat(tempmidi,midifilename);
			 PlayMidiFile(hWnd,tempmidi);
			 }else PlayMidiFile(hWnd,tempmidi);}
			 break;



		  case WM_DROPFILES:
		  char ii[100];
		  HDROP droppedfile;
		  droppedfile=(HDROP) wParam;
			DragQueryFile(droppedfile,0,ii,99);
			DragFinish(droppedfile);
			 wsprintf(tempmidi,"%s",ii);
		  midicount=-1;
			SendMessage(hWnd,WM_COMMAND,MCI_NOTIFY,0);
		  break;



		  case WM_CLOSE:
				musicon=FALSE;
				StopMusic();
				KillTimer(hWnd,ID_TIM1);
				WriteSetupFile();
				PostQuitMessage(0);   // this is the end...
				break;


	/*	  case WM_CLOSE:
				// Tell windows to destroy our window...if you enable these lines
				//there would be an error and
				//I don't know from where error
				// comes,so i disabled them.
				KillTimer(hWnd,ID_TIM);
				DestroyWindow(hWnd);
				break;*/


		  default:
			 // Let windows handle all messages we choose to ignore.
			 return(DefWindowProc(hWnd, Message, wParam, lParam));
	 }

return 0;
}


void InitPuzzle()
{
//randomize();
int maxicons,k,r,z;
maxicons=(int)ExtractIcon(hInst,ICON_FILE,-1);

if(maxicons<=0)
{
char error[100];
wsprintf(error,"Icons file '%s' was not found!",ICON_FILE);
MessageBox(hnd,error,"Error",MB_OK|MB_ICONSTOP);
ExitProcess(-1);
}

icons=(HICON *)GlobalAlloc(GMEM_FIXED,(maxicons)*sizeof(HICON));

if(maxicons<xmax*ymax/2)
{
xmax=7;
ymax=4;
SetWindowPos(hnd,HWND_TOP,0,0,xmax*wdth+6,ymax*lngth+38+TOP_HEIGHT,SWP_NOMOVE);
GetClientRect(hnd,&rc);
remained=xmax*ymax;
MessageBox(hnd,"Not enough icons found! so,resizing to 7x4...","error",MB_OK|MB_ICONSTOP);

}
for(k=0;k<ymax*xmax;k+=2)
{
again:
r=random(maxicons);
for(z=0;z<k;z+=2) if(basepuzzle[z]==r) goto again;
basepuzzle[k]=r;
basepuzzle[k+1]=r;
}
}

void Mixup()
{
int x,z,mx,m2,y,t;
y=xmax*ymax;
for(z=0;z<MIXING_REPEAT;z++)
{
for(x=0;x<y;x++)
{
mx=rand()%y;
t=basepuzzle[mx];
basepuzzle[mx]=basepuzzle[x];
basepuzzle[x]=t;

mx=rand()%y;
t=basepuzzle[mx];
m2=rand()%y;
basepuzzle[mx]=basepuzzle[m2];
basepuzzle[m2]=t;
}


}}








void ExtractAllIcons()
{
int x;
for(x=0;x<xmax*ymax;x+=2)
icons[basepuzzle[x]]=ExtractIcon(hInst,ICON_FILE,basepuzzle[x]);

icon1=LoadIcon(hInst,MAKEINTRESOURCE(ICON_1));
icon2=LoadIcon(hInst,MAKEINTRESOURCE(ICON_2));
icon3=LoadIcon(hInst,MAKEINTRESOURCE(ICON_3));
icon4=LoadIcon(hInst,MAKEINTRESOURCE(ICON_4));
icon5=LoadIcon(hInst,MAKEINTRESOURCE(ICON_5));

}




void DoPaint()
{
	 char          top_string[10];
	 int           x,y;
	 HDC hMemDC,hdc;
	 HBITMAP theBitmap;


hdc=GetDC(hnd);
hMemDC = CreateCompatibleDC(hdc);
theBitmap = CreateCompatibleBitmap(hdc,
								 xmax*wdth,
								 ymax*lngth+TOP_HEIGHT);
SelectObject(hMemDC, theBitmap);
SetBkMode(hMemDC,TRANSPARENT);


FillRect(hMemDC,&rc,BackGround);


for(y=0;y<ymax;y++)
for(x=0;x<xmax;x++)
{
if(showpuzzle[x+y*xmax]>0)
DrawIcon(hMemDC,x*wdth,y*lngth+TOP_HEIGHT,icons[showpuzzle[x+y*xmax]]);
else
if(showpuzzle[x+y*xmax]==-2)
DrawIcon(hMemDC,x*wdth,y*lngth+TOP_HEIGHT,icon2);
else
if(showpuzzle[x+y*xmax]==-1)
DrawIcon(hMemDC,x*wdth,y*lngth+TOP_HEIGHT,icon1);


}

DrawIcon(hMemDC,0,0,icon3);
DrawIcon(hMemDC,70,0,icon5);
DrawIcon(hMemDC,140,0,icon4);

			 wsprintf(top_string,"%4ld ",EllapsedTime);
			 TextOut(hMemDC,32,10,top_string,4);
			 wsprintf(top_string,"%3d ",found);
			 TextOut(hMemDC,103,10,top_string,4);
			 wsprintf(top_string,"%3d ",remained);
			 TextOut(hMemDC,173,10,top_string,4);

		  BitBlt(hdc, 0,0,
					xmax*wdth,
					ymax*lngth+TOP_HEIGHT,
					hMemDC, 0, 0, SRCCOPY);
DeleteDC(hMemDC);
DeleteObject(theBitmap);
ReleaseDC(hnd,hdc);
ValidateRect(hnd,NULL);
}

void NewGame(int x,int y)
{
UnsetMem();
KillTimer(hnd,ID_TIM1);
if((x*y)%2==1)x++;
xmax=x;
ymax=y;
secondselection=FALSE;
if(showremained)Hidepic(hnd,0,0,0);
TimerOn=FALSE;
mousekeydown=FALSE;
found=0;
remained=xmax*ymax;
SetWindowPos(hnd,HWND_TOP,0,0,xmax*wdth+6,ymax*lngth+MENU_HEIGHT+TOP_HEIGHT,SWP_NOMOVE);
GetClientRect(hnd,&rc);
SetMem();
InitPuzzle();
ExtractAllIcons();
Mixup();
EllapsedTime=0;
DoPaint();
}




void UncheckAllBut(int x)
{
HMENU hm=GetMenu(hnd);

CheckMenuItem(hm,CM_ITEM3,MF_UNCHECKED);
CheckMenuItem(hm,CM_ITEM4,MF_UNCHECKED);
CheckMenuItem(hm,CM_ITEM5,MF_UNCHECKED);
CheckMenuItem(hm,CM_ITEM6,MF_UNCHECKED);
CheckMenuItem(hm,x,MF_CHECKED);

}

void UncheckAllBut2(int x)
{
HMENU hm=GetMenu(hnd);

CheckMenuItem(hm,CM_ITEM9,MF_UNCHECKED);
CheckMenuItem(hm,CM_ITEM10,MF_UNCHECKED);
CheckMenuItem(hm,CM_ITEM11,MF_UNCHECKED);
CheckMenuItem(hm,CM_ITEM12,MF_UNCHECKED);


CheckMenuItem(hm,x,MF_CHECKED);


}






BOOL FAR PASCAL About(HWND hDlg, UINT message, WPARAM wParam, LPARAM)
{
	switch (message) {
		 case WM_INITDIALOG:
			  return (TRUE);

		 case WM_COMMAND:
	  if (GET_WM_COMMAND_ID(wParam, lParam) == IDOK) {
					EndDialog(hDlg, TRUE);
					return (TRUE);
			  }
			  break;
	}

	return (FALSE);
}




BOOL FAR PASCAL CustomFlashTime(HWND hDlg, UINT message, WPARAM wParam, LPARAM)
{
	switch (message) {
		 case WM_INITDIALOG:
			  SetDlgItemInt(hDlg,IDC_EDIT1,FlashTime,FALSE);
			  return (TRUE);

		 case WM_COMMAND:
	  if (GET_WM_COMMAND_ID(wParam, lParam) == IDOK) {
					FlashTime=GetDlgItemInt(hDlg,IDC_EDIT1,NULL,FALSE);
					if(FlashTime==0)FlashTime=1;
					EndDialog(hDlg, TRUE);

					return (TRUE);
			  }
			  break;
	}

	return (FALSE);
}



BOOL FAR PASCAL Custom(HWND hDlg, UINT message, WPARAM wParam, LPARAM)
{

	switch (message) {
		 case WM_INITDIALOG:
			  SetDlgItemInt(hDlg,Xmx,xmax,FALSE);
			  SetDlgItemInt(hDlg,Ymx,ymax,FALSE);
			  return (TRUE);

		 case WM_COMMAND:
	  switch(GET_WM_COMMAND_ID(wParam, lParam))
	  {
	  case IDOK: {
					int XMAX=GetDlgItemInt(hDlg,Xmx,NULL,FALSE);
					int YMAX=GetDlgItemInt(hDlg,Ymx,NULL,FALSE);
					if ((XMAX>6)&&(XMAX<LENGTHMAX)&&(YMAX>1)&&(YMAX<HEIGHTMAX)&&(XMAX*YMAX%2==0))
					{
					EndDialog(hDlg, TRUE);
					xmax=XMAX;
					ymax=YMAX;
					}
					else
					{
					SetDlgItemInt(hDlg,Xmx,xmax,FALSE);
					SetDlgItemInt(hDlg,Ymx,ymax,FALSE);
					}
					return(TRUE);
					}


			  }
	}

	return (FALSE);
}


void SetMem()
{
int k;
showpuzzle=(int *)GlobalAlloc(GMEM_FIXED,xmax*ymax*sizeof(int));
for(k=0;k<xmax*ymax;k++)showpuzzle[k]=-2;
basepuzzle=(int *)GlobalAlloc(GMEM_FIXED,xmax*ymax*sizeof(int));
}

void UnsetMem()
{
GlobalFree((HGLOBAL)showpuzzle);
GlobalFree((HGLOBAL)basepuzzle);
GlobalFree((HGLOBAL)icons);
}

void CALLBACK timertasks(HWND,UINT,UINT,DWORD)
{
				 EllapsedTime++;
				 DoPaint();

}


void CALLBACK Hidepic(HWND hWnd,UINT,UINT,DWORD)
{
				 showpuzzle[selected1]=-2;
				 showpuzzle[selected2]=-2;
				 DoPaint();
				 KillTimer(hWnd,ID_TIM2);
				 showremained=FALSE;

}




DWORD PlayMidiFile(HWND hWndNotify, LPSTR lpszMIDIFileName)
{
	 UINT wDeviceID;
	 DWORD dwReturn;
	 MCI_OPEN_PARMS mciOpenParms;
	 MCI_PLAY_PARMS mciPlayParms;
	 MCI_STATUS_PARMS mciStatusParms;

	 /*
	  * Open the device by specifying the
	  * device name and device element.
	  * MCI will attempt to choose the
	  * MIDI Mapper as the output port.

	  */
	 mciOpenParms.lpstrDeviceType = "sequencer";
	 mciOpenParms.lpstrElementName = lpszMIDIFileName;
	 if (dwReturn = mciSendCommand(NULL, MCI_OPEN,
				MCI_OPEN_TYPE | MCI_OPEN_ELEMENT,
				(DWORD)(LPVOID) &mciOpenParms)) {
		  /*
			* Failed to open device;
			* don't close it, just return error.
			*/
			ShowMCIError(dwReturn);
		  return dwReturn;
	 }

	 /* Device opened successfully. Get the device ID. */
	 wDeviceID = mciOpenParms.wDeviceID;

	 /* See if the output port is the MIDI Mapper. */
	 mciStatusParms.dwItem = MCI_SEQ_STATUS_PORT;

	 if (dwReturn = mciSendCommand(wDeviceID, MCI_STATUS,
				MCI_STATUS_ITEM,
				(DWORD)(LPVOID) &mciStatusParms)) {
		  mciSendCommand(wDeviceID, MCI_CLOSE, 0, NULL);
		  ShowMCIError(dwReturn);
		  return dwReturn;
	 }

	 /*
	  * Begin playback. The window procedure function
	  * for the parent window is notified with an
	  * MM_MCINOTIFY message when playback is complete.
	  * The window procedure then closes the device.
	  */
	 mciPlayParms.dwCallback = (DWORD) hWndNotify;
	 if (dwReturn = mciSendCommand(wDeviceID, MCI_PLAY,
				MCI_NOTIFY, (DWORD)(LPVOID) &mciPlayParms)) {
		  mciSendCommand(wDeviceID, MCI_CLOSE, 0, NULL);
		  ShowMCIError(dwReturn);
		  return dwReturn;
	 }

musicdevice=wDeviceID;

	 return 0;
}



void StopMusic()
{
	if(musicdevice)
	 mciSendCommand(musicdevice, MCI_CLOSE,MCI_WAIT,NULL);
}

void ShowMCIError(DWORD errornumber)
{
				 char errorstring[200];
				 mciGetErrorString(errornumber,errorstring,sizeof(errorstring));
				 MessageBox(hnd,errorstring,"ERROR",MB_OK|MB_ICONEXCLAMATION);
				 musicon=FALSE;
				 CheckMenuItem(GetMenu(hnd),CM_ITEM14,MF_UNCHECKED);

}


void ReadSetupFile(HMENU *hm1)
{
HKEY key;
char data[total_menue_items]="\0\0\0\1\0\0\0\1\0\0\1\1\0\0";
DWORD size,type;
HMENU hm2;
int j,i,z=0;

*hm1=LoadMenu(hInst,MAKEINTRESOURCE(Mem_Menu));
if(ERROR_SUCCESS==RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\WinMem",0,KEY_ALL_ACCESS,&key))
{
	size=total_menue_items;
	RegQueryValueEx(key,"ConfigData",0,&type,(UCHAR *)data,&size);
	if(size==total_menue_items)
	{
		for(j=0;j<GetMenuItemCount(*hm1);j++)
			{
				hm2=GetSubMenu(*hm1,j);
				for(i=0;i<GetMenuItemCount(hm2);i++)
					{
					if(data[z])CheckMenuItem(hm2,i,MF_BYPOSITION|MF_CHECKED);
						else CheckMenuItem(hm2,i,MF_BYPOSITION|MF_UNCHECKED);
					z++;
					}
			}
	}
}




size=1;
if(data[2]){xmax=7;ymax=4;}
  else if(data[3]){xmax=7;ymax=6;}
  else if(data[4]){xmax=8;ymax=8;}
  else if(data[5])
		 {RegQueryValueEx(key,"xmax",NULL,&type,(UCHAR *)&xmax,&size);
		  RegQueryValueEx(key,"ymax",NULL,&type,(UCHAR *)&ymax,&size);}

size=2;
if(data[6])FlashTime=EASYFLASH;
  else if(data[7])FlashTime=MEDFLASH;
  else if(data[8])FlashTime=HARDFLASH;
  else if(data[9])RegQueryValueEx(key,"flashtime",NULL,&type,(UCHAR *)&FlashTime,&size);

if(data[10])soundon=TRUE;else soundon=FALSE;
if(data[11])musicon=TRUE;else musicon=FALSE;



}

void WriteSetupFile()
{
DWORD res;
HKEY key;
int i,j,z=0;
char data[total_menue_items];
HMENU hm1,hm2;


	 RegCreateKeyEx(HKEY_CURRENT_USER,"Software\\WinMem",0,NULL,
					REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,
					&key,&res);

hm1=GetMenu(hnd);
for(j=0;j<GetMenuItemCount(hm1);j++)
{
hm2=GetSubMenu(hm1,j);
for(i=0;i<GetMenuItemCount(hm2);i++)
{
if(GetMenuState(hm2,i,MF_BYPOSITION)&MF_CHECKED)
data[z]=1;else data[z]=0;
z++;}
}

	 RegSetValueEx(key,"ConfigData",0,REG_BINARY,(UCHAR *)data,z);
	 RegSetValueEx(key,"flashtime",0,REG_BINARY,(UCHAR *)&FlashTime,2);
	 RegSetValueEx(key,"xmax",0,REG_BINARY,(UCHAR *)&xmax,1);
	 RegSetValueEx(key,"ymax",0,REG_BINARY,(UCHAR *)&ymax,1);

/*	 RegCreateKeyEx(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WinMem",0,NULL,
					REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,
					&key,&res);

wsprintf(str,"WinMem");
	 RegSetValueEx(key,"DisplayName",0,REG_SZ,(UCHAR *)str,lstrlen(str));
GetModuleFileName(hInst,path,sizeof(path));
wsprintf(str,"%s /UNINSTALL",path);
	 RegSetValueEx(key,"UninstallString",0,REG_SZ,(UCHAR *)str,lstrlen(str));
*/


}

/*void UNINSTALLWinMem()
{
	char filename[255];
	char path[255];
	LPSTR tmp;

if(IDYES==MessageBox(NULL,"Are you sure you want to UNINSTALL WinMem?","WARNING",
			  MB_YESNO|MB_DEFBUTTON2|MB_ICONEXCLAMATION))
	 {
		 RegDeleteKey(HKEY_LOCAL_MACHINE,"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\WinMem");
		 RegDeleteKey(HKEY_CURRENT_USER,"Software\\WinMem");

		 //FILES THAT SHOULD BE DELETED
		 GetModuleFileName(NULL,filename,sizeof(filename));
		 GetFullPathName(filename,sizeof(path),path,&tmp);
		 *(tmp)='\0';
		 wsprintf(filename,"%s%s",path,"mem.exe");
		 DeleteFile(filename);



	 MessageBox(NULL,"UNINSTALL completed.","MESSAGE",MB_OK|MB_ICONINFORMATION);
	 }


}*/

int random(int max)
{
	DWORD t;
	t=GetTickCount();
	if(t%4)srand(t%0xfff+1000);
	else if((t%0x00f0>>16)%3)srand(t%0xf+1000);
	else if((t%0x0f00>>32)%2)srand(t%0xff+1000);
	else srand(t%0x500+1000);
Sleep(t&200);


return (rand()%max);
}