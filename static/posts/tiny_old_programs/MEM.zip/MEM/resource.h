//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mem.rc
//
#define AboutBox                        101
#define Mem_Menu                        102
#define ICON_1                          103
#define ICON_5                          104
#define ICON_2                          105
#define ICON_4                          106
#define ICON_3                          107
#define HelpBox                         108
#define CustomFlash                     109
#define CustomSize                      110
#define IDB_BITMAP1                     111
#define IDC_EDIT1                       1000
#define Ymx                             1001
#define Xmx                             1002
#define CM_ITEM1                        40001
#define CM_ITEM2                        40002
#define CM_ITEM3                        40003
#define CM_ITEM4                        40004
#define CM_ITEM5                        40005
#define CM_ITEM6                        40006
#define CM_ITEM9                        40009
#define CM_ITEM14                       40011
#define CM_ITEM15                       40012
#define CM_ITEM7                        40013
#define CM_ITEM8                        40014
#define CM_ITEM10                       40015
#define CM_ITEM11                       40016
#define CM_ITEM12                       40017
#define CM_ITEM13                       40018
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
