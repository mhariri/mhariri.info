/*  
 * ISPUtil Password Decryptor
 * Copyright ParsPooyesh Co. 2005
 * Programmed By: Mohsen Hariri <hariri@parspooyesh.com>
 *  
 *  This file is free software: you may copy, redistribute and/or modify it  
 *  under the terms of the GNU General Public License as published by the  
 *  Free Software Foundation, either version 2 of the License, or (at your  
 *  option) any later version.  
 *  
 *  This file is distributed in the hope that it will be useful, but  
 *  WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  
 *  General Public License for more details.  
 *  
 *  You should have received a copy of the GNU General Public License  
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.  
 *  
 * This file incorporates work covered by the following copyright and  
 * permission notice:  
 *  
 *     Copyright (c) ParsPooyesh Co., Mohsen Hariri <hariri@parspooyesh.com>  
 *  
 *     Permission to use, copy, modify, and/or distribute this software  
 *     for any purpose with or without fee is hereby granted, provided  
 *     that the above copyright notice and this permission notice appear  
 *     in all copies.  
 *  
 *     THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL  
 *     WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED  
 *     WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE  
 *     AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR  
 *     CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS  
 *     OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,  
 *     NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN  
 *     CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  
 */ 
 
#include <openssl\crypto\bf\blowfish.h>
#include <ctype.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>

char todec(const char xx)
{
    char x = tolower(xx);
    if(isdigit(x))
        return x - '0';
    return x - 'a' + 10;
}

int to_str(const char *a, char *b){
    for(int i=0; i<strlen((char *)a); i+=2)
        b[i/2] = (todec(a[i]) << 4) + todec(a[i+1]);
	return i/2;
}




int main(int argc, char **argv){
	if(argc < 2){
		printf("Usage: decrypt HASH");
		return 0;
	}

    unsigned char pass2[100];
    unsigned char pass3[100];
    memset(pass2, 0, sizeof(pass2));

    char key[]="_DOURAN_";

    BF_KEY k;

    BF_set_key(&k, strlen(key), (unsigned char *)key);

	unsigned char vect[10];

    int s = to_str(argv[1], (char *)pass2);
	memset(pass3, 0, sizeof(pass3));
	memcpy(vect, "\x64\x14\x14\x3f\x13\x60\x4e\x1f", 8);
    BF_cbc_encrypt(pass2, pass3, s, &k,vect ,BF_DECRYPT);

    printf("%s\n", pass3);

    return 0;
}
