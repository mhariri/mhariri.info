#include "StdAfx.h"
#include "CalcException.h"
#include "Helpers.h"
#include "tablemanager.h"
#include "LexicalAnalyzer.h"
#include "Parser.h"


CRichEditCtrl *g_Out;

void StartCompiler(CString s, CRichEditCtrl &out)
{
	g_Out = &out;
	Add2Riched(out, "-------------------------------------");
	TRY{
		CLexicalAnalyzer a;

		a.Scan(s);

		CParser p;

		p.Parse(&a);

		Add2Riched(out, a.m_SymTbl.Dump());
	}CATCH(CCalcException, pExc)
	{
		Add2Riched(out, pExc->GetString());
	}
	END_CATCH;
}