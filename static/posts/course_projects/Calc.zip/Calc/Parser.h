#pragma once
#include "ParserRules.h"

#define PARSER_STEP	"Parser"
class CParser
{
public:
	CParser(void);
	~CParser(void);

	void Parse(CLexicalAnalyzer *lex);
	double GetIdVal();
	double GetConstVal();

private:
	void DoReduction(int red);
	int FindTransition(int state, int tok);
	int spop();
	double vpop();
	CLexicalAnalyzer *m_Lex;
	std::stack<int> s;
	std::stack<double> vals;

	int pos;
	int line;

};
