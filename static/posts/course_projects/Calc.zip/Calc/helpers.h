// Calculator Helper functions

void Add2Riched(CRichEditCtrl &r, CString str, BOOL addNewLine=true);
