#pragma once

#define SYMBOL_TABLE	"Symbol Table"

class CSymbol{
public:
	CString name;
	TOKEN type;
    CString extra;
};

class CSymbolTable
{
public:
	CSymbolTable(void);
	~CSymbolTable(void);
	void Add(CString name, int type, CString extra="");
	BOOL IsDefined(CString name);
	int GetType(CString name);
	CString GetExtra(CString name);
	void SetExtra(CString name,CString extra);

	CString Dump(BOOL constants = false);


private:
	int Lookup(CString name, BOOL throw_on_fail = true);
	CArray<CSymbol *> m_Symbols;
};
