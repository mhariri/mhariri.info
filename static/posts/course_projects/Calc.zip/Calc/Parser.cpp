#include "StdAfx.h"
#include "LexicalAnalyzer.h"
#include "CalcException.h"
#include "parser.h"
#include "Helpers.h"

extern CRichEditCtrl *g_Out;

CParser::CParser(void)
{
}

CParser::~CParser(void)
{
}

void CParser::Parse(CLexicalAnalyzer *lex)
{
	m_Lex = lex;
	s.push(PARSE_BEGIN);
	pos = 0;
	line = 0;


	while(line < lex->GetTotalLines()){
		TOKEN tok = lex->GetLine(line)->GetToken(pos);
		PARSE_STATES srr=(PARSE_STATES)s.top();
		int i;
		if((i=FindTransition(s.top(), tok)) == -1){
			CString err;
			err.Format("Parse error at line %d(no such transition).", line+1);
			THROW(new CCalcException(err, PARSER_STEP));
		}

		CString sl;
		if(PARSE_RULE[i*4+2]){ // reduction?
			int red = PARSE_RULE[i*4+3];
			REDUCTIONS ss = (REDUCTIONS)PARSE_RULE[i*4+3];
			sl.Format("REDUCTION %d", red);
			Add2Riched(*g_Out, sl);
			DoReduction(red);
		}else{ // so shift...
			PARSE_STATES ss = (PARSE_STATES)PARSE_RULE[i*4+3];
			sl.Format("SHIFT %d", ss);
			Add2Riched(*g_Out, sl);
			s.push(tok);
			s.push(PARSE_RULE[i*4+3]);
			pos ++;
		}
		if(s.top() == PARSE_ACCEPT){
			while(s.size())
				s.pop();
			s.push(PARSE_BEGIN);
			pos = 0;
			line ++;
		}
	}
}

void CParser::DoReduction(int red)
{
	double t1,t2;
	CString ts,name;
	// semantic actions
	switch(red){
		case RED_1:
			VERIFY(spop() == 'E');
			VERIFY(spop() == T_EQU);
			VERIFY(spop() == T_IDENTIFIER);
			s.push(T_END);

			t1 = vpop();
			name = m_Lex->GetLine(line)->GetTokenParam(0);
			ts.Format("%lf", t1);
			m_Lex->m_SymTbl.SetExtra(name,ts);
			break;

		case RED_2:
			VERIFY(spop() == 'E');
			s.push(T_END);

			t1 = vpop();
			ts.Format("line %d value: %lf", line+1, t1);
			Add2Riched(*g_Out, ts);
			break;

		case RED_3:
			VERIFY(spop() == 'T');
			VERIFY(spop() == T_ADD);
			VERIFY(spop() == 'E');
			s.push('E');

			t1 = vpop();
			t2 = vpop();
			vals.push(t1+t2);
			break;

		case RED_4:
			VERIFY(spop() == 'T');
			VERIFY(spop() == T_MIN);
			VERIFY(spop() == 'E');
			s.push('E');

			t1 = vpop();
			t2 = vpop();
			vals.push(t2-t1);
			break;

		case RED_5:
			VERIFY(spop() == 'T');
			s.push('E');

			// no value change
			break;


		case RED_6:
			VERIFY(spop() == 'F');
			VERIFY(spop() == T_MUL);
			VERIFY(spop() == 'T');
			s.push('T');

			t1 = vpop();
			t2 = vpop();
			vals.push(t2*t1);
			break;

		case RED_7:
			VERIFY(spop() == 'F');
			VERIFY(spop() == T_DIV);
			VERIFY(spop() == 'T');
			s.push('T');

			t1 = vpop();
			t2 = vpop();
			vals.push(t2/t1);
			break;

		case RED_8:
			VERIFY(spop() == 'F');
			s.push('T');

			// no value change
			break;

		case RED_9:
			VERIFY(spop() == T_PARA_C);
			VERIFY(spop() == 'E');
			VERIFY(spop() == T_PARA_O);
			s.push('F');

			// no value change
			break;

		case RED_10:
			VERIFY(spop() == T_IDENTIFIER);
			VERIFY(spop() == T_MIN);
			s.push('F');

			vals.push(-GetIdVal());
			break;

		case RED_11:
			VERIFY(spop() == T_IDENTIFIER);
			s.push('F');

			vals.push(GetIdVal());
			break;


		case RED_12:
			VERIFY(spop() == T_CONSTANT);
			VERIFY(spop() == T_MIN);
			s.push('F');

			vals.push(-GetConstVal());
			break;

		case RED_13:
			VERIFY(spop() == T_CONSTANT);
			VERIFY(spop() == T_ADD);
			s.push('F');

			vals.push(GetConstVal());
			break;

		case RED_14:
			VERIFY(spop() == T_CONSTANT);
			s.push('F');

			vals.push(GetConstVal());
			break;


	}

	// find next state
	int i;
	int v = s.top();
	s.pop();
	PARSE_STATES st = (PARSE_STATES)s.top();
	if((i=FindTransition(st,v)) == -1){
			CString err;
			err.Format("Parse error at line %d(no state found after reducion).", line+1);
			THROW(new CCalcException(err, PARSER_STEP));
	}
	s.push(v);
	PARSE_STATES ee = (PARSE_STATES)PARSE_RULE[i*4+3];
	s.push(PARSE_RULE[i*4+3]);

}

int CParser::FindTransition(int state, int tok)
{
		for(int i=0; i<sizeof(PARSE_RULE)/sizeof(int)/4; i++){
			if(PARSE_RULE[i*4] == state && PARSE_RULE[i*4+1] == tok)
				return i;
		}

		return -1;
}

int CParser::spop()
{
	s.pop();
	int a = s.top();
	s.pop();
	return a;
}

double CParser::vpop()
{
	double a = vals.top();
	vals.pop();
	return a;
}

double CParser::GetIdVal()
{
	CString name, ts;

	name = m_Lex->GetLine(line)->GetTokenParam(pos-1);
	ts = m_Lex->m_SymTbl.GetExtra(name);
	if(!ts.GetLength()){
		CString err;
		err.Format("Varaiable '%s' used before assignment on line %d.", name, line+1);
		THROW(new CCalcException(err, PARSER_STEP));
	}

	return atof(ts);
}

double CParser::GetConstVal()
{
	CString name;

	name = m_Lex->GetLine(line)->GetTokenParam(pos-1);

	return atof(name);
}