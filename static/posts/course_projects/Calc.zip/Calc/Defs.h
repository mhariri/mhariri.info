#pragma once

// token types
enum TOKEN{ T_CONSTANT, T_IDENTIFIER, T_MUL, T_DIV, T_MIN, T_ADD, T_MOD, T_PARA_O, T_PARA_C, T_EQU, T_POW, T_END};