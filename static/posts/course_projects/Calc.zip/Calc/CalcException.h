#pragma once

class CCalcException :
	public CException
{
public:
	CCalcException(CString err, CString step = "");
	~CCalcException(void);

	CString GetString();

private:
	CString m_Error, m_Step;
};
