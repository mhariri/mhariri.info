#include "StdAfx.h"
#include "Defs.h"
#include "symboltable.h"
#include "CalcException.h"

CSymbolTable::CSymbolTable(void)
{
}

CSymbolTable::~CSymbolTable(void)
{
	for(int i=0; i<m_Symbols.GetSize(); i++)
		delete m_Symbols[i];
}

void CSymbolTable::Add(CString name, int type, CString extra)
{
	if(IsDefined(name))
		return;
	
	CSymbol *s = new CSymbol();
	s->name = name;
	s->type = (TOKEN)type;
	s->extra = extra;

	m_Symbols.Add(s);
}

BOOL CSymbolTable::IsDefined(CString name)
{
	return Lookup(name,false)==-1?0:1;
}

int CSymbolTable::GetType(CString name)
{
	return m_Symbols[Lookup(name)]->type;
}

CString CSymbolTable::GetExtra(CString name)
{
	return m_Symbols[Lookup(name)]->extra;
}

void CSymbolTable::SetExtra(CString name,CString extra)
{
	m_Symbols[Lookup(name)]->extra = extra;
}


int CSymbolTable::Lookup(CString name, BOOL throw_on_fail)
{
	for(int i=0; i<m_Symbols.GetSize(); i++)
		if(!m_Symbols[i]->name.Compare(name))
			return i;

	if(throw_on_fail){
		CString str;
		str.Format("symbol '%s' not defined.", name);
		THROW(new CCalcException(str, SYMBOL_TABLE));
	}

	return -1;
}

CString CSymbolTable::Dump(BOOL constants)
{
	CString s, t;
	
	s = "\nSymbol Table Contents:\n";
	for(int i=0; i<m_Symbols.GetSize(); i++) {
		if(!constants && m_Symbols[i]->type == T_CONSTANT)
			continue;
		t.Format("%-20s %-15s %-20s\n", m_Symbols[i]->name,
								m_Symbols[i]->type == T_IDENTIFIER ? "ID": "Const.",
								m_Symbols[i]->extra);
		s += t;
	}

	return s;
}