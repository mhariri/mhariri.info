#pragma once

void StartCompiler(CString s, CRichEditCtrl &out);
