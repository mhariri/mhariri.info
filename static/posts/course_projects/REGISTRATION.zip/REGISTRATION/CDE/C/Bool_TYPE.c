void
INI_Bool_TYPE() 
{
  ;
}
