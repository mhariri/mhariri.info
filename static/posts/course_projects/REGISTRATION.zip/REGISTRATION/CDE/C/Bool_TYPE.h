extern char * _Bool_TYPE_BOOL [];
#define BOOL _Bool_TYPE_BOOL
#define TRUE  1
#define FALSE 0

void INI_Bool_TYPE();
