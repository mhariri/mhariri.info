// MemDlg.h : header file
//

#pragma once

#include "Speech.h"

enum STATE{ HIDDEN, SELECTED, TURNED, SOLVED};

// CMemDlg dialog
class CMemDlg : public CDialog
{
// Construction
public:
	CMemDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MEM_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	int *m_PuzzleIcons;
	STATE *m_PuzzleState;
	int m_XSize, m_YSize;
	HICON *m_Icons;
	int m_IconsCount;

	CSpeech m_Speech;


	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	void OnLButtonDown(UINT s, CPoint p);
	DECLARE_MESSAGE_MAP()
public:
	// Loads the icons
	int LoadIcons(void);
	int MakePuzzle(void);
	void CleanUp(void);
	// returns the rectangle for the specified box index
	CRect GetIndexRect(int index);
	// resizes the dialog to fit the content boxes
	void ResizeToContent(void);
	// returns selected item index, -1 on none
	int GetSelection(void);
protected:
	void OnTimer(UINT id);
	LRESULT SpeechEvent(WPARAM wParam, LPARAM lParam);
public:
	void Hit(int index);
	CPoint GetClientDiffer(void);
	int CheckWin(void);
	void CMemDlg::OnOK();
};
