#pragma once
#include "Speech.h"


// CWonDialog dialog

class CWonDialog : public CDialog
{
	DECLARE_DYNAMIC(CWonDialog)

public:
	CWonDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CWonDialog();

// Dialog Data
	enum { IDD = IDD_WONDIALOG };

protected:
	CSpeech m_Speech;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	BOOL OnInitDialog();
	LRESULT SpeechEvent(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedNewgame();
	afx_msg void OnBnClickedExit();
};
