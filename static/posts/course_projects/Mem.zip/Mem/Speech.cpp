#include "StdAfx.h"
#include "speech.h"

CSpeech::CSpeech(LPWSTR sGrammerFile)
{
    m_cpRecoCtxt = 0;
	m_cpLexicon = 0;
	m_cpPhoneConv = 0;
	m_cpCmdGrammar = 0;


    HRESULT hr = S_OK;
    CComPtr<ISpRecognizer> cpRecoEngine;
	
	hr = cpRecoEngine.CoCreateInstance(CLSID_SpSharedRecognizer);

    if( SUCCEEDED( hr ) )
    {
		AfxMessageBox("1");
        hr = cpRecoEngine->CreateRecoContext( &m_cpRecoCtxt );
    }
    if (SUCCEEDED(hr))
    {
		AfxMessageBox("2");
        // This specifies which of the recognition events are going to trigger notifications.
        // Here, all we are interested in is the beginning and ends of sounds, as well as
        // when the engine has recognized something
		const ULONGLONG ullInterest = SPFEI(SPEI_RECOGNITION);
        hr = m_cpRecoCtxt->SetInterest(ullInterest, ullInterest);
    }
    if (SUCCEEDED(hr))
    {
		hr = LoadGrammar(sGrammerFile);
	}
	if( !SUCCEEDED( hr ))
	{
		CString s;
		s.Format("0x%lx", hr);
		AfxMessageBox("Error occured while initializing speech engine! Code: " + s);
		ExitProcess(0);
	}

	
}

CSpeech::~CSpeech(void)
{
    if(m_cpRecoCtxt)
		m_cpRecoCtxt.Release();
	if(m_cpLexicon)
		m_cpLexicon.Release();
	if(m_cpPhoneConv)
		m_cpPhoneConv.Release();
	if(m_cpCmdGrammar)
		m_cpCmdGrammar.Release();
}


DWORD CSpeech::StartEngine(int iNotificationType, void *lParam)
{
    HRESULT hr = S_OK;
	
	switch(iNotificationType)
	{
	case SPEECH_NOTIFY_MESSAGE:
		// Set recognition notification for dictation
		if(!SUCCEEDED(m_cpRecoCtxt->SetNotifyWindowMessage( (HWND)lParam, WM_RECOEVENT, 0, 0 )))
			return 1;
		m_iNotificationType = iNotificationType;
		m_lNotoficationParam = lParam;
		break;

	case SPEECH_NOTIFY_CALLBACK:
		break;

	default:
		AfxMessageBox("Invalid speech notification type!");
		return 1;
		break;
	}

	return 0;
}

DWORD CSpeech::Pause()
{
	return !SUCCEEDED(m_cpCmdGrammar->SetGrammarState(SPGS_DISABLED));
}

DWORD CSpeech::Resume()
{
	return !SUCCEEDED(m_cpCmdGrammar->SetGrammarState(SPGS_ENABLED));
}

DWORD CSpeech::AddString(CString sRule, CString sPhrase)
{
	SPSTATEHANDLE hRule;
    HRESULT hr = S_OK;
    if(SUCCEEDED(hr))
    {
		m_cpCmdGrammar->GetRule(sRule.AllocSysString(), 0, SPRAF_Dynamic | SPRAF_Active, false, &hRule);
	}
    if(SUCCEEDED(hr))
    {
		hr = m_cpCmdGrammar->AddWordTransition(hRule, NULL, sPhrase.AllocSysString(), NULL, SPWT_LEXICAL, 1, NULL);
	}
    if(SUCCEEDED(hr))
    {
		hr = m_cpCmdGrammar->Commit(0);
	}
	return !SUCCEEDED(hr);
}

DWORD CSpeech::DeleteAll(CString sRule)
{
	SPSTATEHANDLE hRule;
    HRESULT hr = S_OK;
    if(SUCCEEDED(hr))
    {
		m_cpCmdGrammar->GetRule(sRule.AllocSysString(), 0, SPRAF_Dynamic | SPRAF_Active, false, &hRule);
	}
    if(SUCCEEDED(hr))
    {
		hr = m_cpCmdGrammar->ClearRule(hRule);
	}
    if(SUCCEEDED(hr))
    {
		hr = m_cpCmdGrammar->Commit(0);
	}
	return !SUCCEEDED(hr);
}

DWORD CSpeech::AddPersianPronounciations()
{
	LANGID langidUS = MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US);
    SPPHONEID wszId[SP_MAX_PRON_LENGTH];
    HRESULT hr = S_OK;
	CString sCommand,sName;

	if(sCommand && sCommand.GetLength()) {
		BSTR cm = sCommand.AllocSysString();
		while(SUCCEEDED(hr) && cm)
		{
			wchar_t *w = wcschr(cm, (wchar_t)'|');
			if(w)
				*w = 0;
			hr = m_cpPhoneConv->PhoneToId(cm, wszId);
			cm = w;
		}
		if(SUCCEEDED(hr))
		{
			hr = m_cpLexicon->AddPronunciation(sName.AllocSysString(), langidUS, SPPS_Noun, wszId);
		}
	}
	return !SUCCEEDED(hr);
}

DWORD CSpeech::LoadGrammar(LPWSTR sGrammerFile)
{
	HRESULT hr = S_OK;
    if(SUCCEEDED(hr))
    {
		hr = m_cpRecoCtxt->CreateGrammar(GRAMMARID1, &m_cpCmdGrammar);
	}
    if(SUCCEEDED(hr))
    {
		hr = m_cpCmdGrammar->LoadCmdFromFile(sGrammerFile, SPLO_DYNAMIC);
	}
    if (SUCCEEDED(hr))
    {
		hr = m_cpCmdGrammar->SetRuleState(NULL, NULL, SPRS_ACTIVE );
	}
	return hr;
}

LPWSTR CSpeech::GetSpokenPhrase()
{
	LPWSTR pwszSpokenPhrase;
	HRESULT hr = S_OK;
	CComPtr<ISpRecoResult> cpRecoResult = GetSpokenResult();
	if (cpRecoResult) {
		SPPHRASE* pPhrase = NULL;

		// get the phrase object from the recognition result
		hr = cpRecoResult->GetPhrase(&pPhrase);
		if (SUCCEEDED(hr) && pPhrase) {
			hr = cpRecoResult->GetText(SP_GETWHOLEPHRASE,
										SP_GETWHOLEPHRASE,
										FALSE,
										&pwszSpokenPhrase,
										NULL);
		}
		// free the phrase object
		if (pPhrase) ::CoTaskMemFree(pPhrase);
	}else
		hr = S_FALSE;
	if(SUCCEEDED(hr))
		return pwszSpokenPhrase;
	return NULL;
}

CComPtr<ISpRecoResult> CSpeech::GetSpokenResult()
{
	CSpEvent spEvent;
	HRESULT hr = S_OK;

       // if event retrieved and it is a recognition
	if (S_OK == spEvent.GetFrom(m_cpRecoCtxt) && SPEI_RECOGNITION == spEvent.eEventId) {
		// get the recognition result
		return spEvent.RecoResult();
	}
	return NULL;
}