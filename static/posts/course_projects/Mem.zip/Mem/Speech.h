#pragma once

#pragma warning(push)
#pragma warning(disable: 4267)
#include <sphelper.h>
#pragma warning(pop)

// application notification type
#define SPEECH_NOTIFY_MESSAGE	1
#define SPEECH_NOTIFY_CALLBACK	2


#define WM_RECOEVENT    WM_APP      // Window message used for recognition events

#define GRAMMARID1	161

class CSpeech
{
public:
	CSpeech(LPWSTR);
	~CSpeech(void);

	DWORD StartEngine(int iNotificationType, void *lParam);
	DWORD Pause();
	DWORD Resume();

	DWORD AddString(CString sRule, CString sPrase);
	DWORD DeleteAll(CString sRule);

	DWORD AddPersianPronounciations();
	DWORD LoadGrammar(LPWSTR);
	LPWSTR GetSpokenPhrase();
	CComPtr<ISpRecoResult> GetSpokenResult();
private:
	int m_iNotificationType;
	void *m_lNotoficationParam;
    CComPtr<ISpRecoContext>     m_cpRecoCtxt;
	CComPtr<ISpLexicon>	m_cpLexicon;
	CComPtr<ISpPhoneConverter> m_cpPhoneConv;
	CComPtr<ISpRecoGrammar>	m_cpCmdGrammar;
};
