// WonDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Mem.h"
#include "WonDialog.h"

#define RULE_NAME	"TODO"

// CWonDialog dialog

#define NEWGAME_CMD		"play"
#define EXIT_CMD		"exit"

IMPLEMENT_DYNAMIC(CWonDialog, CDialog)
CWonDialog::CWonDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CWonDialog::IDD, pParent)
	,m_Speech(L"won.xml")
{
}

CWonDialog::~CWonDialog()
{
}

void CWonDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CWonDialog, CDialog)
	ON_BN_CLICKED(IDC_NEWGAME, OnBnClickedNewgame)
	ON_BN_CLICKED(IDC_EXIT, OnBnClickedExit)
	ON_MESSAGE(WM_RECOEVENT, SpeechEvent)
END_MESSAGE_MAP()


// CWonDialog message handlers

void CWonDialog::OnBnClickedNewgame()
{
	EndDialog(IDC_NEWGAME);
}

void CWonDialog::OnBnClickedExit()
{
	EndDialog(IDC_EXIT);
}

BOOL CWonDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	CString sExit, sNewGame;

	m_Speech.StartEngine(SPEECH_NOTIFY_MESSAGE, GetSafeHwnd());
	m_Speech.DeleteAll(RULE_NAME);
	m_Speech.AddString(RULE_NAME, NEWGAME_CMD);
	m_Speech.AddString(RULE_NAME, EXIT_CMD);
	m_Speech.Resume();
	return FALSE;
}

LRESULT CWonDialog::SpeechEvent(WPARAM wParam, LPARAM lParam)
{
	CString s;
	CString sExit, sNewGame;

	s = (LPWSTR)m_Speech.GetSpokenPhrase();

	if(!s.Compare(NEWGAME_CMD))
		OnBnClickedNewgame();
	if(!s.Compare(EXIT_CMD))
		OnBnClickedExit();

	return false;
}