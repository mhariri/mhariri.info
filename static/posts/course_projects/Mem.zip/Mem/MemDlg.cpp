// MemDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Mem.h"
#include "MemDlg.h"
#include "nums.h"
#include "WonDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define ICON_LIBRARY "icons.dll"
#define ICON_X	45
#define ICON_Y	45
#define HEADER_HEIGHT	40
#define BORDER_WIDTH	5

#define FLASH_TIME		1000

#define IDT_FLASH		191
#define RULE_NAME	"Number"


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMemDlg dialog



CMemDlg::CMemDlg(CWnd* pParent /*=NULL*/)
: CDialog(CMemDlg::IDD, pParent)
,m_Speech(L"mem.xml")
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_PuzzleIcons = NULL;
	m_Icons = NULL;
	m_IconsCount = 0;
}

void CMemDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMemDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	ON_WM_TIMER()
	ON_MESSAGE(WM_RECOEVENT, SpeechEvent)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CMemDlg message handlers

BOOL CMemDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_YSize = m_XSize = 4;
	srand(GetTickCount());

	m_Speech.StartEngine(SPEECH_NOTIFY_MESSAGE, GetSafeHwnd());

    VERIFY(LoadIcons());    
	VERIFY(MakePuzzle());
	ResizeToContent();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMemDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CMemDlg::OnPaint() 
{
	CDialog::OnPaint();

	CDC *dc = GetWindowDC();
	CPoint p = GetClientDiffer();
	// draw borders
	dc->Draw3dRect(0, p.y,
					m_XSize * ICON_X + BORDER_WIDTH * 2 + 2 + 2 + 3,
					m_YSize * ICON_Y + HEADER_HEIGHT + BORDER_WIDTH * 3 + 4 + 2 ,
					RGB(255,255,255), RGB(127,127,127));
		
	dc->Draw3dRect(p.x + BORDER_WIDTH + 1, p.y + BORDER_WIDTH + 1,
					m_XSize * ICON_X + 2,
					HEADER_HEIGHT + 2,
					RGB(127,127,127),RGB(255,255,255));

	dc->Draw3dRect(p.x + BORDER_WIDTH + 1, p.y + BORDER_WIDTH * 2 + 3 + HEADER_HEIGHT,
					m_XSize * ICON_X + 2,
					m_YSize * ICON_Y + 2,
					RGB(127,127,127),RGB(255,255,255));

	CRect rc;
	int index;
	for(index = 0; index < m_YSize*m_XSize; index++){
		rc = GetIndexRect(index);
		rc.OffsetRect(p);
		switch(m_PuzzleState[index])
		{
		case TURNED:
		case SOLVED:
			DrawIconEx(dc->m_hDC, rc.TopLeft().x, rc.TopLeft().y ,
					m_Icons[m_PuzzleIcons[index]],
					0, 0, 0, NULL, DI_NORMAL | DI_COMPAT | DI_DEFAULTSIZE);
				dc->Draw3dRect(rc, RGB(127,127,127), RGB(255,255,255));
			break;

		case SELECTED:
		case HIDDEN:
			if(m_PuzzleState[index] == HIDDEN)
				dc->Draw3dRect(rc, RGB(255,255,255), RGB(127,127,127));
			else
				dc->Draw3dRect(rc, RGB(127,127,127), RGB(255,255,255));
			CString a;
			a.Format("%d", index+1);
			CFont f;
			f.CreatePointFont(3, "Courier");
			CFont *old = dc->SelectObject(&f);
			dc->SetBkMode(TRANSPARENT);
			dc->DrawText(a, rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
			dc->SelectObject(old);
			f.DeleteObject();
			break;
		}
	}

	ReleaseDC(dc);
}

HCURSOR CMemDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// Loads the icons
#pragma warning(disable: 4311) 
int CMemDlg::LoadIcons(void)
{
	ASSERT(m_Icons == NULL);
	HICON hi;
	int i=0;

	int total = (int)(void *)ExtractIcon(NULL, ICON_LIBRARY, -1);
	if(total == 0 || total == 1)
		return 0;

    m_Icons = (HICON *)malloc(total * sizeof(HICON));
	while((hi = ExtractIcon(NULL, ICON_LIBRARY, i)) && i < total){
		if(hi == (HICON)1)
			return 0;
		m_Icons[i] = hi;
		i++;
	}
	m_IconsCount = i;

	return 1;
}
#pragma warning(default: 4311) 
int CMemDlg::MakePuzzle(void)
{
	ASSERT(m_PuzzleIcons == NULL);
	// should be even
	ASSERT(!(m_XSize * m_YSize % 2));
	// check for enough icons
	if(m_XSize * m_YSize / 2 > m_IconsCount){
		AfxMessageBox("Not enough icons!");
		return 0;
	}
	m_PuzzleIcons = (int *)malloc(m_XSize * m_YSize * sizeof(int));
	bool rep = false;
	int c;
	for(int i=0; i<m_XSize * m_YSize; i+=2){
		do{
			c = rand()%m_IconsCount;
			rep = false;
			for(int k=0; k<i; k+=2)
				if(m_PuzzleIcons[k] == c){
					rep = true;
					break;
				}
		}while(rep);
		m_PuzzleIcons[i] = c;
		m_PuzzleIcons[i+1] = c;
	}

	for(int i=0; i<m_XSize * m_YSize; i++){
		int r = rand() % (m_XSize * m_YSize - 1) + 1;
		int t = m_PuzzleIcons[r];
		m_PuzzleIcons[r] = m_PuzzleIcons[i];
		m_PuzzleIcons[i] = t;
	}

	m_PuzzleState = (STATE *)malloc(m_XSize * m_YSize * sizeof(int));
	for(int i=0; i<m_XSize * m_YSize; i++)
		m_PuzzleState[i] = HIDDEN;

	VERIFY(!m_Speech.DeleteAll(RULE_NAME));	
	for(int i=0; i<m_XSize * m_YSize; i++){
		VERIFY(!m_Speech.AddString(RULE_NAME, NUMS[i]));
	}

	VERIFY(!m_Speech.Resume());

	return 1;
}

void CMemDlg::CleanUp(void)
{
	if(m_PuzzleIcons){
		free(m_PuzzleIcons);
		m_PuzzleIcons = NULL;
	}
/*	if(m_Icons){
		for(int i=0; i<m_IconsCount; i++)
			DestroyIcon(m_Icons[i]);
		free(m_Icons);
		m_Icons = NULL;
	}
*/
}

// returns the rectangle for the specified box index
CRect CMemDlg::GetIndexRect(int index)
{
	int x = index % m_XSize;
	int y = index / m_XSize;
	return CRect(x * ICON_X + BORDER_WIDTH + 2 + 1 ,
				y * ICON_Y  + HEADER_HEIGHT + BORDER_WIDTH * 2 + 4 + 1,
				x * ICON_X  + ICON_X - 2 + BORDER_WIDTH + 2 ,
				y * ICON_Y  + ICON_Y - 2 + HEADER_HEIGHT + BORDER_WIDTH * 2 + 4 );
}

void CMemDlg::OnLButtonDown(UINT s, CPoint p)
{
	CRect rc;
	for(int index = 0; index < m_YSize * m_XSize; index++){
		rc = GetIndexRect(index);
		if(rc.PtInRect(p))
			Hit(index);
	}
	return CDialog::OnLButtonDown(s, p);
}


// resizes the dialog to fit the content boxes
void CMemDlg::ResizeToContent(void)
{
	CPoint p = GetClientDiffer();
	SetWindowPos(NULL,0,0,
					m_XSize * ICON_X + BORDER_WIDTH * 2 + 2 + 2 + p.x,
					m_YSize * ICON_Y + HEADER_HEIGHT + BORDER_WIDTH * 3 + 4 + 2 + p.y,
					SWP_NOZORDER | SWP_NOMOVE);
}

// returns selected item index, -1 on none
int CMemDlg::GetSelection(void)
{
	for(int i=0; i < m_XSize * m_YSize; i++)
		if(m_PuzzleState[i] == SELECTED)
			return i;
	return -1;
}

void CMemDlg::OnTimer(UINT id)
{
	switch(id){
		case IDT_FLASH:
			for(int i=0; i<m_XSize*m_YSize; i++)
				if(m_PuzzleState[i] == TURNED){
					m_PuzzleState[i] = HIDDEN;
					InvalidateRect(GetIndexRect(i));
				}
			break;
	}
}

void CMemDlg::Hit(int index)
{
	int i;
	if(index >= m_XSize * m_YSize)
		return;
	CRect rc = GetIndexRect(index);
	if(m_PuzzleState[index] == SELECTED){
		m_PuzzleState[index] = HIDDEN;
		InvalidateRect(GetIndexRect(index));
        return;		
	}
	if(m_PuzzleState[index] == TURNED){
		m_PuzzleState[index] = HIDDEN;
	}

	if(m_PuzzleState[index] == HIDDEN){
		if((i=GetSelection()) == -1)
		{
			for(i=0; i<m_XSize * m_YSize; i++)
				if(m_PuzzleState[i] == TURNED){
					m_PuzzleState[i] = HIDDEN;
					InvalidateRect(GetIndexRect(i));
				}

			m_PuzzleState[index] = SELECTED;
			InvalidateRect(rc);
		}
		else{
			if(m_PuzzleIcons[index] == m_PuzzleIcons[i])
			{
				m_PuzzleState[index] = SOLVED;
				m_PuzzleState[i] = SOLVED;
			}else{
				m_PuzzleState[index] = TURNED;
				m_PuzzleState[i] = TURNED;
				SetTimer(IDT_FLASH, FLASH_TIME, NULL);
			}
			InvalidateRect(GetIndexRect(i));
			InvalidateRect(rc);
		}
	}

	CheckWin();
}

CPoint CMemDlg::GetClientDiffer(void)
{
	CPoint p;
	CRect wrc,crc;
	GetWindowRect(&wrc);
	GetClientRect(&crc);
	p = crc.TopLeft();
	ClientToScreen(&p);
	p = p - wrc.TopLeft();
	return p;
}

int CMemDlg::CheckWin(void)
{
	for(int i=0; i<m_XSize * m_YSize; i++)
		if(m_PuzzleState[i] != SOLVED)
			return 0;
	m_Speech.Pause();
	CWonDialog wd;
	int ret = (int)wd.DoModal();
	CleanUp();
	if(ret == IDC_NEWGAME){
		MakePuzzle();
		Invalidate();
	}else
		EndDialog(0);
	m_Speech.Resume();
	return 1;
}

void CMemDlg::OnOK()
{
}

LRESULT CMemDlg::SpeechEvent(WPARAM wParam, LPARAM lParam)
{
	CString s;
	s = (LPWSTR)m_Speech.GetSpokenPhrase();
	for(int i=0; i<m_XSize*m_YSize; i++)
		if(!s.CollateNoCase(NUMS[i])){
			Hit(i);
			break;
		}
	return 0;
}