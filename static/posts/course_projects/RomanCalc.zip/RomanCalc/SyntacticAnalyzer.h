#pragma once

using namespace std;

class CSyntacticAnalyzer
{
public:
	CSyntacticAnalyzer(CRichEditCtrl &out, bool pdbg, bool rdbg);
	~CSyntacticAnalyzer(void);
	// applies transitions on specified lical analyzed output
	int Apply(CLexicalAnalyzer *lex);

	int FindTransition(CString st, TOKEN inp);

	int IsTerminal(CString st);
	TOKEN Term(CString st);
	void DumpTokens(CLexicalAnalyzer *lex, int pos);
	void DumpStack(stack<CString> &s);

	int pred(CString s);
	int eval();

	void eval_add(TOKEN type, CString x);



	stack<CString> s;
	CRichEditCtrl *m_out;
	bool m_dbg, m_rdbg;

	CStringArray postfix;
	stack<CString> ops;

};
