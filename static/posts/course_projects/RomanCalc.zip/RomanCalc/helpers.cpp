// Calculator Helper functions

#include "stdafx.h"

void Add2Riched(CRichEditCtrl *r, CString str, BOOL addNewLine)
{
	CHARRANGE cr;

	cr.cpMin = cr.cpMax = -1;
	if(addNewLine)
		str = str + "\n";
	r->SetSel(cr);

	r->ReplaceSel(str);

	int min,max;
	CRect rc;
	r->GetScrollRange(SB_VERT, &min, &max);
	r->GetRect(rc);
	POINT p;
	p.x = 0;
	p.y = max - rc.Height();
	if(p.y < 0)
		p.y = 0;

	r->SendMessage(EM_SETSCROLLPOS, SB_VERT, (LPARAM)&p);

}

void Add2Riched(CRichEditCtrl &r, CString str, BOOL addNewLine)
{
	Add2Riched(&r, str, addNewLine);
}
