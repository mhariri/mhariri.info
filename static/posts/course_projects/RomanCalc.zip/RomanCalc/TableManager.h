#pragma once

void StartCompiler(CString s, CRichEditCtrl &out, bool pdbg, bool rdbg);
