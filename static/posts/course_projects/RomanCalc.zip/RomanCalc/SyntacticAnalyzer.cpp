#include "StdAfx.h"
#include "LexicalAnalyzer.h"
#include "CalcException.h"
#include "syntacticanalyzer.h"
#include "helpers.h"
#include "RomanNumber.h"


struct TRANS{
	char * state;
	TOKEN  input;
	int result_count;
	char * result[5];
};

static TRANS transforms[] = {
//	state	input			result count	result
	{"E",	T_CONSTANT,		2,				{"T", "E'"}},
	{"E",	T_PARA_O,		2,				{"T", "E'"}},

	{"E'",	T_ADD,			3,				{"+", "T", "E'"}},
	{"E'",	T_MIN,			3,				{"-", "T", "E'"}},
	{"E'",	T_PARA_C,		1,				"$"},
	{"E'",	T_END,			1,				"$"},

	{"T",	T_CONSTANT,		2,				{"F", "T'"}},
	{"T",	T_PARA_O,		2,				{"F", "T'"}},

	{"T'",	T_ADD,			1,				"$"},
	{"T'",	T_MIN,			1,				"$"},
	{"T'",	T_MUL,			3,				{"*", "F", "T'"}},
	{"T'",	T_DIV,			3,				{"/", "F", "T'"}},
	{"T'",	T_PARA_C,		1,				"$"},
	{"T'",	T_END,			1,				"$"},

	{"F",	T_CONSTANT,		1,				{"id"}},
	{"F",	T_PARA_O,		3,				{"(", "E", ")"}},

	{""}// end flag

};

CSyntacticAnalyzer::CSyntacticAnalyzer(CRichEditCtrl &out, bool pdbg, bool rdbg)
{
	m_out = &out;
	m_dbg = pdbg;
	m_rdbg = rdbg;

}

CSyntacticAnalyzer::~CSyntacticAnalyzer(void)
{
}

// applies transitions on specified lical analyzed output
int CSyntacticAnalyzer::Apply(CLexicalAnalyzer *lex)
{
	int val = 0;

	s.push("$");
	s.push("E");
	int ip = 0;

	if(m_dbg){
		DumpStack(s);
		DumpTokens(lex, ip);
		Add2Riched(m_out, "");
	}


	while(s.size())
	{
		CString st = s.top();
		s.pop();
		TOKEN inp = lex->GetLine(0)->GetToken(ip);

		// if terminal
		if(IsTerminal(st))
		{
			if(inp != Term(st))
			{
				Add2Riched(m_out, "ParseError: Unexpected terminal : "
									+ CString(TokenString[inp]) );
				return -1;
			}
			if(inp != T_END)
			{
				if(inp == T_CONSTANT)
				{
					CString rn = lex->GetLine(0)->GetTokenParam(ip);
					if(m_rdbg)
						Add2Riched(m_out, "-------------  Now parsing " + rn);
					CRomanNumber n(*m_out, m_rdbg);
					int new_val = n.value(rn);
					if(new_val)
					{
						CString o;
						o.Format("%ld", new_val);
						if(m_rdbg)
							Add2Riched(m_out, "-------------  Parse Done, value : " + o);
						else
							Add2Riched(m_out, "(Roman number '"+ rn +"' evaluated to: " + o + ")");

						eval_add(inp, o);
					}
					else
						return -1;

				}else
				{
					eval_add(inp, TokenString[inp]);
				}

				if(m_dbg)
				{
					DumpStack(s);
					DumpTokens(lex, ip);
					Add2Riched(m_out, "");
				}
			}
			ip ++;
		
		}
		else
		{
			int i = FindTransition(st, inp);

			// transition found?
			if(i<0)
			{
				Add2Riched(m_out, "ParseError: No applicable rule found "
									"(state : " + st + ", token:" + TokenString[inp] + ")");
				return -1;
			}
			else
			{
				// apply the rule
				for(int j=transforms[i].result_count-1; j>=0; j--)
					if(strcmp(transforms[i].result[j], "$"))
						s.push(transforms[i].result[j]);

				CString rule = st + "->";
				for(int j=0; j<transforms[i].result_count; j++)
						rule += transforms[i].result[j];
				if(m_dbg)
				{
					DumpStack(s);
					DumpTokens(lex, ip);
					Add2Riched(m_out, rule);
				}

			}
		}

	}

	while(ops.size())
	{
		postfix.Add(ops.top());
		ops.pop();
	}

	return eval();
}

int CSyntacticAnalyzer::FindTransition(CString st, TOKEN inp)
{
	int i=0;

	while(strlen(transforms[i].state))
	{
		if(inp == transforms[i].input &&
			!st.Compare(transforms[i].state))
			return i;

		i++;
	}

	return -1;

}

int CSyntacticAnalyzer::IsTerminal(CString st)
{
	return Term(st) != -1;
}

TOKEN CSyntacticAnalyzer::Term(CString st)
{
	for(int i=0; i<sizeof(TokenString)/sizeof(char *); i++)
		if(!st.Compare(TokenString[i]))
			return (TOKEN)i;
	return (TOKEN)-1;
}

void CSyntacticAnalyzer::DumpTokens(CLexicalAnalyzer *lex, int pos)
{
	CString str;
	for(int i=pos; i<lex->GetLine(0)->GetLength(); i++)
		str += TokenString[lex->GetLine(0)->GetToken(i)];
	CString str2;
	str2.Format("%-20s", str);
	Add2Riched(m_out,str2 , false);
}

void CSyntacticAnalyzer::DumpStack(stack<CString> &s)
{
		// print the stack
	stack<CString> ss;
	while(s.size()){
		ss.push(s.top());
		s.pop();
	}

	CString str;
	while(ss.size()){
		s.push(ss.top());
		str += ss.top();
		ss.pop();
	}
	CString str2;
	str2.Format("%-20s", str);

	Add2Riched(m_out, str2 , false);
}

int CSyntacticAnalyzer::pred(CString s)
{
	static char * p[] = {"*", "/", "+", "-", "("};


	for(int i=0; i<sizeof(p)/sizeof(char *); i++)
		if(!s.Compare(p[i]))
			return 100-i;

	ASSERT(FALSE);

	
}

int CSyntacticAnalyzer::eval()
{
	stack<int> res;



	for(int i=0; i<postfix.GetSize(); i++)
	{
		CString t = postfix.GetAt(i);
		int o1,o2;
		if(!t.Compare("*"))
		{
			o1 = res.top();
			res.pop();
			o2 = res.top();
			res.pop();
			res.push(o1 * o2);
		}else
		if(!t.Compare("+"))
		{
			o1 = res.top();
			res.pop();
			o2 = res.top();
			res.pop();
			res.push(o1 + o2);
		}else
		if(!t.Compare("/"))
		{
			o1 = res.top();
			res.pop();
			o2 = res.top();
			res.pop();
			res.push(o2 / o1);
		}else
		if(!t.Compare("-"))
		{
			o1 = res.top();
			res.pop();
			o2 = res.top();
			res.pop();
			res.push(o2 - o1);
		}else
			res.push(atoi((LPCSTR)t));
	}



	return res.top();
}

void CSyntacticAnalyzer::eval_add(TOKEN type, CString x)
{
	switch(type)
	{
	case T_CONSTANT:
		postfix.Add(x);
		break;
	
	case T_PARA_O:
		ops.push(x);
		break;

	case T_PARA_C:
		while(ops.size() && ops.top().Compare("("))
		{
			postfix.Add(ops.top());
			ops.pop();
		}
		if(ops.size()) // drop open paranteses
			ops.pop();
		break;

	default:
		while(ops.size() && pred(x) < pred(ops.top()))
		{
			postfix.Add(ops.top());
			ops.pop();
		}
		ops.push(x);
		break;
	}
}