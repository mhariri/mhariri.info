
enum LEX_STATES{LEX_BEGIN, LEX_CONST};

/////////////////////////// CHAR	CUR STATE	NEXT STATE	REMOVE?
const int TRANS_TABLE[] = { 'I',	LEX_BEGIN,	LEX_CONST,	true,
							'V',	LEX_BEGIN,	LEX_CONST,	true,
							'X',	LEX_BEGIN,	LEX_CONST,	true,
							'L',	LEX_BEGIN,	LEX_CONST,	true,
							'C',	LEX_BEGIN,	LEX_CONST,	true,
							'D',	LEX_BEGIN,	LEX_CONST,	true,
							'M',	LEX_BEGIN,	LEX_CONST,	true,

							'I',	LEX_CONST,	LEX_CONST,	true,
							'V',	LEX_CONST,	LEX_CONST,	true,
							'X',	LEX_CONST,	LEX_CONST,	true,
							'L',	LEX_CONST,	LEX_CONST,	true,
							'C',	LEX_CONST,	LEX_CONST,	true,
							'D',	LEX_CONST,	LEX_CONST,	true,
							'M',	LEX_CONST,	LEX_CONST,	true,

};
