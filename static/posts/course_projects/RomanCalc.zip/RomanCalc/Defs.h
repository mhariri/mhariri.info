#pragma once

// token types
enum TOKEN{ T_CONSTANT, T_MUL, T_DIV, T_MIN, T_ADD, T_PARA_O, T_PARA_C, T_END};
static char * TokenString[] = {"id", "*", "/", "-", "+", "(", ")", "$"};
