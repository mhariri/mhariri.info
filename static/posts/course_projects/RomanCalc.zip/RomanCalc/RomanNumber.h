#pragma once

using namespace std;
class CRomanNumber
{
public:
	CRomanNumber(CRichEditCtrl &out, bool dbg);
	~CRomanNumber(void);

	// applies transitions on specified lical analyzed output
	int value(CString num);

	int FindTransition(CString st, CString inp);

	int IsTerminal(CString st);
	CString Term(CString st);
	void DumpTokens(CString num, int pos);
	void DumpStack(stack<CString> &s);


	stack<CString> s;
	CRichEditCtrl *m_out;
	bool m_dbg;
};
