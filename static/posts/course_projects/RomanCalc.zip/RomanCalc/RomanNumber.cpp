#include "StdAfx.h"
#include "romannumber.h"

#include "LexicalAnalyzer.h"
#include "CalcException.h"
#include "helpers.h"

struct TRANS2{
	char * state;
	int input_count;
	char * input[10];
	int result_count;
	char * result[5];
};

static TRANS2 transforms[] = {
//	state	count input			result count	result
	{"id",	6,			{"I","II","III", "IV", "V", "IX"},			1,				{"id4"}},
	{"id",	6,			{"X", "XX", "XXX", "XL", "L", "XC"},		2,				{"id5", "id4"}},
	{"id",	6,			{"C", "CC", "CCC", "CD", "D", "CM"},	3,				{"id6", "id5", "id4"}},
	{"id",	1,			{"M"},										1,				{"id7"}},

	{"id1",	1,			{"I"},		1, {"I"}},
	{"id1",	1,			{"II"},		1, {"II"}},
	{"id1",	1,			{"III"},	1, {"III"}},
	{"id1",	1,			{"$"},		1, {"$"}},

	{"id2",	1,			{"X"},		1, {"X"}},
	{"id2",	1,			{"XX"},		1, {"XX"}},
	{"id2",	1,			{"XXX"},	1, {"XXX"}},
	{"id2",	1,			{"$"},		1, {"$"}},

	{"id3",	1,			{"C"},		1, {"C"}},
	{"id3",	1,			{"CC"},		1, {"CC"}},
	{"id3",	1,			{"CCC"},	1, {"CCC"}},
	{"id3",	1,			{"$"},		1, {"$"}},

	{"id4",	3,			{"I", "II", "III"},	1,	{"id1"}},
	{"id4",	1,			{"IV"},				1,	{"IV"}},
	{"id4",	1,			{"V"},				2,	{"V", "id1"}},
	{"id4",	1,			{"IX"},				1,	{"IX"}},
	{"id4",	1,			{"$"},				1, {"$"}},

	{"id5",	3,			{"X", "XX", "XXX"},	1,	{"id2"}},
	{"id5",	1,			{"XL"},				1,	{"XL"}},
	{"id5",	1,			{"L"},				2,	{"L", "id2"}},
	{"id5",	1,			{"XC"},				1,	{"XC"}},
	{"id5",	1,			{"$"},				1, {"$"}},

	{"id6",	3,			{"C", "CC", "CCC"},	1,	{"id3"}},
	{"id6",	1,			{"CD"},				1,	{"CD"}},
	{"id6",	1,			{"D"},				2,	{"D", "id3"}},
	{"id6",	1,			{"CM"},				1,	{"CM"}},
	{"id6",	1,			{"$"},				1, {"$"}},

	{"id7",	1,			{"M"},				1,	{"M"}},
	{"id7",	1,			{"$"},				1, {"$"}},

	{""}// end flag

};

char * terminals[] = {
						"III", "XXX", "CCC",
						"II", "XX", "CC", "IV", "IX", "XL", "XC", "CD", "CM",
						"I", "X", "C", "V", "L", "D", "M",

						"$",
						NULL
					
					};
int terminal_val[] = {
						3, 30, 300,
						2, 20, 200, 4, 9, 40, 90, 400, 900,
						1, 10, 100, 5, 50, 500, 1000,

						0,
				
					};

CRomanNumber::CRomanNumber(CRichEditCtrl &out, bool dbg)
{
	m_out = &out;
	m_dbg = dbg;
}

CRomanNumber::~CRomanNumber(void)
{
}

// applies transitions on specified lical analyzed output
int CRomanNumber::value(CString num)
{
	num += "$";
	int val = 0;
	s.push("$");
	s.push("id");
	int ip = 0;

	if(m_dbg)
	{
		DumpStack(s);
		DumpTokens(num, ip);
		Add2Riched(m_out, "");
	}

	while(s.size())
	{
		CString st = s.top();
		s.pop();

		// find longest match
		CString inp;
		int inp_val;
		int i=0;
		while(terminals[i])
		{
			if(num.GetLength() - ip >= strlen(terminals[i]) &&
				!strncmp(terminals[i], (LPCSTR)num.Mid(ip), strlen(terminals[i])))
			{
				inp = terminals[i];
				inp_val = terminal_val[i];
				break;
			}
			i++;
		}

		if(inp == "")
		{
			Add2Riched(m_out, "ParseError: Not parse-able: " + num);
			return -1;
		}

		// if terminal
		if(IsTerminal(st))
		{
			if(inp != Term(st))
			{
				Add2Riched(m_out, "ParseError: Unexpected terminal : "
									+ st );
				return 0;

			}
			val += inp_val;
			ip += inp.GetLength();
			if(ip < num.GetLength() && m_dbg)
			{
				DumpStack(s);
				DumpTokens(num, ip);
				Add2Riched(m_out, "");
			}
		}
		else
		{
			int i = FindTransition(st, inp);

			// transition found?
			if(i<0)
			{
				Add2Riched(m_out, "ParseError: No applicable rule found "
									"(state : " + st + ", token:" + inp + ")");
				return 0;
			}
			else
			{
				// apply the rule
				for(int j=transforms[i].result_count-1; j>=0; j--)
					if(strcmp(transforms[i].result[j], "$"))
						s.push(transforms[i].result[j]);

				CString rule = st + "->";
				for(int j=0; j<transforms[i].result_count; j++)
						rule += transforms[i].result[j];
				if(m_dbg)
				{
					DumpStack(s);
					DumpTokens(num, ip);
					Add2Riched(m_out, rule);
				}

			}
		}

	}

	return val;

}

int CRomanNumber::FindTransition(CString st, CString inp)
{
	int i=0;

	while(strlen(transforms[i].state))
	{
		for(int j=0; j<transforms[i].input_count; j++)
		{
			if(!inp.Compare(transforms[i].input[j]) &&
				!st.Compare(transforms[i].state))
				return i;
		}

		i++;
	}

	return -1;

}

int CRomanNumber::IsTerminal(CString st)
{
	return strlen((LPCSTR)Term(st));
}

CString CRomanNumber::Term(CString st)
{
		int i=0;
		while(terminals[i]){
			if(!st.Compare(terminals[i]))
				return st;
			i++;
		}

		return "";
}

void CRomanNumber::DumpTokens(CString num, int pos)
{
	CString str2;
	str2.Format("%-20s", num.Mid(pos));
	Add2Riched(m_out,str2 , false);
}

void CRomanNumber::DumpStack(stack<CString> &s)
{
		// print the stack
	stack<CString> ss;
	while(s.size()){
		ss.push(s.top());
		s.pop();
	}

	CString str;
	while(ss.size()){
		s.push(ss.top());
		str += ss.top();
		ss.pop();
	}
	CString str2;
	str2.Format("%-20s", str);

	Add2Riched(m_out, str2 , false);
}
