#include "StdAfx.h"
#include "lexicalanalyzer.h"
#include "Defs.h"
#include "CalcException.h"


static CString seperators	= _T(" \n\t\r");
static CString operators	= _T("+-*/()");
static LEX_VALS operator_vals[]	= {LEX_ADD, LEX_MIN, LEX_MUL, LEX_DIV, LEX_PARA_O, LEX_PARA_C};

CLexicalAnalyzer::CLexicalAnalyzer(void)
{
}

CLexicalAnalyzer::~CLexicalAnalyzer(void)
{
	for(int i=0; i<m_ScannedLines.GetSize(); i++)
		delete m_ScannedLines[i];
}

// scanns the input 
void CLexicalAnalyzer::Scan(CString input)
{
	m_Input = input;
	LEX_VALS newTok;
	int pos = 0;
	int curLine = 1;
	CString param;
	CLine *line = new CLine();

	do {
		newTok = GetNextState(input, pos, param);
		switch(newTok) {
			case LEX_VCONST:
				line->AddToken(T_CONSTANT, param);
				break;
			case LEX_MIN:
				line->AddToken(T_MIN);
				break;
			case LEX_MUL:
				line->AddToken(T_MUL);
				break;
			case LEX_ADD:
				line->AddToken(T_ADD);
				break;
			case LEX_DIV:
				line->AddToken(T_DIV);
				break;
			case LEX_PARA_C:
				line->AddToken(T_PARA_C);
				break;
			case LEX_PARA_O:
				line->AddToken(T_PARA_O);
				break;


			case LEX_NEW_LN:
				line->AddToken(T_END);
				m_ScannedLines.Add(line);
				curLine ++;
				line = new CLine();
				break;

			case LEX_ERROR:
				CString err;
				err.Format("Syntax error at line %d.", curLine+1);
				THROW(new CCalcException(err, LEX_STR));
				break;
		}
	}while(newTok != LEX_END);
	line->AddToken(T_END);
	m_ScannedLines.Add(line);
	curLine ++;

}

// return the specified line
CLine *CLexicalAnalyzer::GetLine(int lineNo)
{
	return m_ScannedLines[lineNo];
}

// returns total lines count
int CLexicalAnalyzer::GetTotalLines(void)
{
	return (int)m_ScannedLines.GetSize();
}


LEX_VALS CLexicalAnalyzer::GetNextState(CString input, int &pos, CString &param)
{
	LEX_STATES curState = LEX_BEGIN;

	param = "";
	TCHAR c = 0;

	while(true){
		if(input.GetLength() <= pos) {
			if(curState == LEX_BEGIN)
				return LEX_END;
			else
				c = 0;
		}else
			c = input.GetAt(pos);

		// set alphabets to their uppercase form
		if(isalpha(c))
			c = toupper(c);

		// find proper state transition
		int i;
		if((i = FindTransition(c, curState)) != -1) {
			curState = (LEX_STATES)TRANS_TABLE[i*4 + 2];
			if(TRANS_TABLE[i*4 + 3]){
				pos ++;
				param += c;
			}
			continue;
		}

		if(operators.Find(c) != -1) {
			if(curState == LEX_BEGIN){
					pos ++;
					return operator_vals[operators.Find(c)];
			}
		}

		if(input.GetLength() <= pos || seperators.Find(c) != -1 || operators.Find(c) != -1) {
			switch(curState){
				case LEX_CONST:
					return LEX_VCONST;
				case LEX_BEGIN:
					pos ++;
					if(c == '\n' || c == '\r')
						return LEX_NEW_LN;
					break;
				default:
					return LEX_ERROR;
			}
			continue;
		}
		return LEX_ERROR;
	}
}

int CLexicalAnalyzer::FindTransition(int ch, int state)
{
	for(int i=0; i<sizeof(TRANS_TABLE) / sizeof(int) / 4; i++)
		if(TRANS_TABLE[i*4] == ch && TRANS_TABLE[i*4 + 1] == state)
			return i;

	return -1;
}