#pragma once
#include "Line.h"
#include "LexerTransitions.h"


enum LEX_VALS{LEX_VCONST,
				LEX_MIN, LEX_ADD, LEX_MUL, LEX_DIV, LEX_PARA_O, LEX_PARA_C, LEX_NEW_LN,
				LEX_END, LEX_ERROR};



#define LEX_STR	"Lexical Analyzer"

class CLexicalAnalyzer
{
public:
	CLexicalAnalyzer(void);
	~CLexicalAnalyzer(void);
	// scanns the input and builds symbol table
	void Scan(CString input);
	// return the specified line
	CLine *GetLine(int lineNo);
	// returns total lines count
	int GetTotalLines(void);

private:
	CString m_Input;
	CString m_LastToken;
	CArray<CLine *> m_ScannedLines;
	LEX_VALS GetNextState(CString input, int &pos, CString &param);

	int FindTransition(int ch, int state);

};
