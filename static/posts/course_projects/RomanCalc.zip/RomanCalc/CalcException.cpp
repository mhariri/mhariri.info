#include "StdAfx.h"
#include "calcexception.h"

CCalcException::CCalcException(CString err, CString step)
{
	m_Step = (LPCSTR)step;
	m_Error = (LPCSTR)err;
}

CCalcException::~CCalcException(void)
{
}

CString CCalcException::GetString()
{
	return m_Step + ": " + m_Error;
}
