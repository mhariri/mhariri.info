#include "StdAfx.h"
#include "line.h"

CLine::CLine(void)
{
}

CLine::~CLine(void)
{
}

// adds a token to the end of this line
void CLine::AddToken(TOKEN tok, CString param)
{
	m_Content.Add(tok);
	m_Params.Add(param);
}

int CLine::GetLength()
{
	return (int)m_Content.GetSize();
}

TOKEN CLine::GetToken(int i)
{
	return m_Content[i];
}

CString CLine::GetTokenParam(int i)
{
	return m_Params[i];
}

CString CLine::Dump()
{
	CString ret;
	for(int i=0; i<m_Content.GetSize(); i++)
		ret += TokenString[m_Content[i]];

	return ret;
}
