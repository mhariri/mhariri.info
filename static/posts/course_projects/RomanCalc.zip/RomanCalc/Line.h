#pragma once
#include "Defs.h"

class CLine
{
public:
	CLine(void);
	~CLine(void);
	// adds a token to the end of this line
	void AddToken(TOKEN tok, CString param="");

	CString Dump();

	int GetLength();
	TOKEN GetToken(int i);
	CString GetTokenParam(int i);

private:
	CArray<TOKEN> m_Content;
	CArray<CString> m_Params;
};
