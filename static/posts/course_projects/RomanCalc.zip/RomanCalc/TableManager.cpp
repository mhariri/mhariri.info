#include "StdAfx.h"
#include "CalcException.h"
#include "Helpers.h"
#include "tablemanager.h"
#include "LexicalAnalyzer.h"
#include "SyntacticAnalyzer.h"
#include "RomanNumber.h"


void StartCompiler(CString s, CRichEditCtrl &out, bool pdbg, bool rdbg)
{
	Add2Riched(out, "\nStarting evaluation of '" + s + "'");
	TRY{
		CLexicalAnalyzer a;

		a.Scan(s);

		if(a.GetTotalLines()){
			Add2Riched(out, "Lixically analyzed expression: " + a.GetLine(0)->Dump());
		}

		CSyntacticAnalyzer sa(out,pdbg, rdbg);
		int val = sa.Apply(&a);

		if(val >= 0)
		{
			CString r;
			r.Format("%ld", val);
			Add2Riched(out, "Evaluation done, expression evaluates to: " + r );
		}

	}CATCH(CCalcException, pExc)
	{
		Add2Riched(out, pExc->GetString());
	}
	END_CATCH;
}