//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mfcgui.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_POINTER                     104
#define IDR_MAINFRAME                   128
#define IDR_PROCTYPE                    129
#define IDR_DUMMY1                      130
#define IDD_RENAME_VARIABLE             131
#define IDD_NEW_PROJECT                 132
#define IDD_VIEWDECODE                  133
#define IDD_PROCEDURES                  135
#define IDD_SAVELOAD                    136
#define IDD_CFGVIEW                     137
#define IDD_EDITBB                      139
#define IDD_SYMBOLS                     141
#define IDB_TRENT                       143
#define IDD_NEWSYMBOL                   144
#define IDD_PROC_PROPERTIES             146
#define IDD_DATA_FLOW                   147
#define IDC_INDICATE_FOLLOW             149
#define IDC_INDICATE_LATCH              150
#define IDC_UP                          1003
#define IDC_DOWN                        1004
#define IDC_BOTH                        1005
#define IDC_NAME                        1006
#define IDC_NEWNAME                     1007
#define IDC_BROWSE_FILENAME             1007
#define IDC_BROWSE_LOCATION             1008
#define IDC_FILENAME                    1009
#define IDC_LOADER                      1011
#define IDC_FRONTEND                    1012
#define IDC_LOCATION                    1013
#define IDC_STATUS                      1013
#define IDC_PROGRESS                    1014
#define IDC_COMPLETE                    1015
#define IDC_PROCTREE                    1016
#define IDC_UNDECODED                   1017
#define IDC_INSTRUCTION                 1018
#define IDC_PROCEDURE                   1019
#define IDC_PROBLEM                     1020
#define IDC_PROCS                       1024
#define IDC_CALLEDBY                    1025
#define IDC_CALLS                       1026
#define IDC_SAVELOADPROGRESS            1028
#define IDC_MESSAGE                     1029
#define IDC_TREE                        1030
#define IDC_GRAPH                       1031
#define IDC_AUTOARRANGE                 1032
#define IDC_TYPE                        1035
#define IDC_CONDTYPE                    1036
#define IDC_LOOPHEAD                    1037
#define IDC_CASEHEAD                    1038
#define IDC_CONDFOLLOW                  1039
#define IDC_TAB                         1039
#define IDC_LOOPFOLLOW                  1040
#define IDC_LATCHNODE                   1041
#define IDC_LIST                        1042
#define IDC_EXP                         1043
#define IDC_LOCAL                       1045
#define IDC_GLOBAL                      1046
#define IDC_EDIT1                       1051
#define IDC_EDIT2                       1052
#define ID_RENAME_VARIABLE              32771
#define ID_VIEW_PROCEDURES              32772
#define ID_EDIT_CODE                    32773
#define ID_PROPERTIES                   32774
#define ID_VIEW_CONTROLFLOW             32775
#define ID_EDIT_BB                      32776
#define ID_SHOW_ALL_LABELS              32777
#define ID_HIDE_UN_LABELS               32778
#define ID_VIEW_SYMBOLS                 32779
#define ID_PROJECT_NEW                  32780
#define ID_PROJECT_OPEN                 32781
#define ID_PROJECT_CLOSE                32782
#define ID_PROJECT_SAVE                 32783
#define ID_PROJECT_SAVE_AS              32784
#define ID_NEW_SYMBOL                   32785
#define ID_DELETE_SYMBOL                32786
#define ID_FIX_INVALID_CFG              32787
#define ID_SHOW_LEAVES                  32788
#define ID_EDIT_PROC                    32789
#define ID_SHOW_STRUCTURES              32790
#define ID_REMOVE_USELESS               32791
#define ID_MAKE_SSA                     32792
#define ID_PROPOGATE_FORWARD            32793
#define ID_MAKE_IF_THEN                 32794
#define ID_MAKE_IF_THEN_ELSE            32795
#define ID_CHANGE_FOLLOW                32796
#define ID_DEBUG_EXP                    32797
#define ID_SIMPLIFY_EXP                 32798
#define ID_CHANGE_LATCH                 32799
#define ID_MAKE_PRETESTED_LOOP          32800
#define ID_REV_SSA_FORM                 32801

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32802
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
