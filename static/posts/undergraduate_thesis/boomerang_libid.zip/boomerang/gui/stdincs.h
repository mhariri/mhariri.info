
#include <string>
#include <iostream>
#include <fstream>
#include <list>

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include "wx/wx.h"
    #include "wx/mdi.h"
#endif

#include "wx/config.h"
#include "wx/dir.h"

using namespace std;
