void *__builtin_new(int bytes);
