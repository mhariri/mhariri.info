stat_ppc.h
