void *_Znwj(int bytes);
void *_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc(void* stream, char* str);
void* _ZNSolsEm(void* stream, int u);
void* _ZNSolsEPFRSoS_E(void* stream, void* string);
void* _ZNSolsEl(void* stream, int l);
