char *gluErrorString(GLenum errorCode);
