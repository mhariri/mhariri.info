int getopt(int argc, char *argv[], const char *optstring);

