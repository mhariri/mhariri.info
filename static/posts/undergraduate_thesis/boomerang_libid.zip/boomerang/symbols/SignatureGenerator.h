#pragma once

class SignatureGenerator
{
public:
	SignatureGenerator(void);
	~SignatureGenerator(void);
};
