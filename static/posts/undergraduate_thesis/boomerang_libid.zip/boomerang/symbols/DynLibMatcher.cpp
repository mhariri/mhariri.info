#include "DynLibMatcher.h"

DynLibMatcher::DynLibMatcher(Prog *prog)
:SymbolMatcher(prog)
{
}

DynLibMatcher::~DynLibMatcher(void)
{
}
