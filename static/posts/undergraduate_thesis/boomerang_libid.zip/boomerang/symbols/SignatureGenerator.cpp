#include "SignatureGenerator.h"

SignatureGenerator::SignatureGenerator(void)
{
}

SignatureGenerator::~SignatureGenerator(void)
{
}
