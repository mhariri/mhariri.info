#include "LibSigMatcher.h"

LibSigMatcher::LibSigMatcher(Prog *prog)
:SymbolMatcher(prog)
{
}

LibSigMatcher::~LibSigMatcher(void)
{
}
