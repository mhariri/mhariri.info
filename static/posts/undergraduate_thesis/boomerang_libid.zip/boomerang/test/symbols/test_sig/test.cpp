#include <stdio.h>



int main()
{
	printf("Works...\n");
	thisthis(10);

	return 0;
}


int thisthis(int pp){

	printf("thisthis");
	int i=0;
	while(i < pp) {
		printf("11");
	}
	if(pp>5)
		printf("122");
	return i;
}