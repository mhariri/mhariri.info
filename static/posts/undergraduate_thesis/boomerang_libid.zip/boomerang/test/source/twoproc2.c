
int proc1(int a, int b) {
    return a + b;
}

int main() {
    printf("%i\n", proc1(3, 4));
    printf("%i\n", proc1(5, 6));
}


