#include <stdio.h>

int main() {
    float pi = 3.1415926;
    printf("Pi is about %.5f\n", pi);
    return 0;
}
