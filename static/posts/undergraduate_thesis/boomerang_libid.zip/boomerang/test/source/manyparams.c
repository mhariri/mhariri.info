#include <stdio.h>

int main() {
    printf("Many parameters: %d, %.1f, %d, %.1f, %d, %.1f, %d, %.1f\n",
        1, 1.1, 2, 2.2, 3, 3.3, 4, 4.4);
    return 0;
}
